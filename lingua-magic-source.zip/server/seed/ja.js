'use strict';

/**
 * 日语（ja）种子数据：沉浸式多语言学习平台。
 * 纯 CommonJS，无任何外部依赖。
 */

module.exports = {
  language: {
    code: 'ja',
    name: '日语',
    name_native: '日本語',
    flag: '🇯🇵',
    voice: 'ja-JP',
    intro: '掌握日语，直通动漫、科技与匠人文化。'
  },
  courses: [
    {
      level: 'A1',
      level_order: 1,
      title: '日语入门',
      subtitle: 'にほんご入門',
      description: '从五十音与寒暄语起步，打好发音与基础句型。',
      icon: '🌸',
      lessons: [
        {
          title: '基础寒暄语',
          module: 'vocabulary',
          order_index: 1,
          xp: 15,
          duration_min: 6,
          description: '学习日常见面与道别时最常用的寒暄表达。',
          exercises: [
            {
              type: 'mcq',
              prompt: '「こんにちは」は何を意味しますか。',
              prompt_translation: '「こんにちは」是什么意思？',
              audio: null,
              options: ['你好', '再见', '谢谢', '对不起'],
              answer: '你好',
              explanation: '「こんにちは」是白天见面时最常用的寒暄语，相当于中文的「你好」。',
              hint: '白天见面时的问候语。'
            },
            {
              type: 'mcq',
              prompt: '早上见面时应该说：',
              prompt_translation: '早上见面时应该说哪一句？',
              audio: null,
              options: ['おはようございます', 'こんばんは', 'おやすみなさい', 'さようなら'],
              answer: 'おはようございます',
              explanation: '「おはようございます」是早晨见面时的敬语，比「おはよう」更礼貌。',
              hint: '用于早晨打招呼。'
            },
            {
              type: 'fill',
              prompt: '晚上道别时说「____」。',
              prompt_translation: '晚上道别时说的那句话是什么？',
              audio: null,
              options: null,
              answer: 'おやすみなさい',
              explanation: '「おやすみなさい」用于晚上分别或睡前，相当于中文的「晚安」。',
              hint: '睡前或夜晚道别时使用。'
            },
            {
              type: 'mcq',
              prompt: '「ありがとうございます」の意味は何ですか。',
              prompt_translation: '「ありがとうございます」是什么意思？',
              audio: null,
              options: ['谢谢', '不客气', '请', '抱歉'],
              answer: '谢谢',
              explanation: '「ありがとうございます」是「谢谢」的敬语表达，语感更郑重。',
              hint: '表达感谢之意的敬语。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '你好，田中先生。',
              audio: 'こんにちは、田中さん。',
              options: null,
              answer: 'こんにちは、田中さん。',
              explanation: '跟读时注意「こんにちは」的「は」作助词时读作 wa，不读 ha。',
              hint: '注意助词「は」读作 wa。'
            }
          ]
        },
        {
          title: '数字与时间',
          module: 'vocabulary',
          order_index: 2,
          xp: 15,
          duration_min: 6,
          description: '认识日语数字读音与常见时间的表达方式。',
          exercises: [
            {
              type: 'mcq',
              prompt: '「三」の読み方はどれですか。',
              prompt_translation: '「三」的读音是哪一个？',
              audio: null,
              options: ['さん', 'に', 'いち', 'よん'],
              answer: 'さん',
              explanation: '「三」读作「さん」，是表示数量「3」的常用读音。',
              hint: '数字三的读音。'
            },
            {
              type: 'mcq',
              prompt: '「七」の読み方はどれですか。',
              prompt_translation: '「七」的读音是哪一个？',
              audio: null,
              options: ['なな', 'しち', 'ろく', 'きゅう'],
              answer: 'なな',
              explanation: '为避免与「死（し）」同音，现代日语中「七」多读作「なな」。',
              hint: '「七」的常用读音。'
            },
            {
              type: 'fill',
              prompt: '现在三点，日文说「今は____時です」。',
              prompt_translation: '现在是三点，日文中「时」前面应填哪个数字读音？',
              audio: null,
              options: null,
              answer: '三',
              explanation: '「三時」读作「さんじ」，表示「三点钟」。',
              hint: '三点钟的「三」。'
            },
            {
              type: 'mcq',
              prompt: '「明日」の読み方はどれですか。',
              prompt_translation: '「明日」的读音是哪一个？',
              audio: null,
              options: ['あした', 'きのう', 'きょう', 'あさって'],
              answer: 'あした',
              explanation: '「明日」读作「あした」，表示「明天」；「今日」读作「きょう」。',
              hint: '表示「明天」的词。'
            },
            {
              type: 'fill',
              prompt: '日文里表示「星期一」的词是「____」。',
              prompt_translation: '日文中「星期一」用哪个词表示？',
              audio: null,
              options: null,
              answer: '月曜日',
              explanation: '「月曜日」读作「げつようび」，是「星期一」，由「月」加「曜日」构成。',
              hint: '星期一到星期日都以「曜日」结尾。'
            }
          ]
        },
        {
          title: '助词入门',
          module: 'grammar',
          order_index: 3,
          xp: 20,
          duration_min: 8,
          description: '掌握は/を/に/の等基础助词的用法。',
          exercises: [
            {
              type: 'mcq',
              prompt: '私は学生____。',
              prompt_translation: '我是学生。空格处应填哪个助词？',
              audio: null,
              options: ['です', 'ます', 'でした', 'でしたら'],
              answer: 'です',
              explanation: '名词句用「です」结句，「私は学生です」意为「我是学生」。',
              hint: '名词谓语句的礼貌结句。'
            },
            {
              type: 'fill',
              prompt: '私は日本語____勉強します。',
              prompt_translation: '我学习日语。空格处应填哪个助词？',
              audio: null,
              options: null,
              answer: 'を',
              explanation: '「を」标记动作的直接宾语，「日本語を勉強します」即「学习日语」。',
              hint: '宾语助词。'
            },
            {
              type: 'mcq',
              prompt: '学校____行きます。',
              prompt_translation: '去学校。空格处应填哪个助词？',
              audio: null,
              options: ['に', 'を', 'は', 'で'],
              answer: 'に',
              explanation: '「行きます」表移动，「に」标记移动的目的地。',
              hint: '表示去向的助词。'
            },
            {
              type: 'mcq',
              prompt: 'これは私____本です。',
              prompt_translation: '这是我的书。空格处应填哪个助词？',
              audio: null,
              options: ['の', 'は', 'が', 'を'],
              answer: 'の',
              explanation: '「の」连接两个名词表示所属，「私の本」即「我的书」。',
              hint: '表示所属关系的助词。'
            },
            {
              type: 'fill',
              prompt: '田中さん____会います。',
              prompt_translation: '和 Tanaka 先生见面。空格处应填哪个助词？',
              audio: null,
              options: null,
              answer: 'に',
              explanation: '「会います」用「に」标记见面的对象。「田中さんに会います」意为「和 Tanaka 先生见面」。',
              hint: '表示动作对象的助词。'
            }
          ]
        },
        {
          title: '自我介绍',
          module: 'speaking',
          order_index: 4,
          xp: 20,
          duration_min: 8,
          description: '用日语进行简单的自我介绍与礼貌表达。',
          exercises: [
            {
              type: 'speak',
              prompt: '请跟读这句自我介绍。',
              prompt_translation: '初次见面，我叫小王。',
              audio: 'はじめまして。わたしは王と申します。',
              options: null,
              answer: 'はじめまして。わたしは王と申します。',
              explanation: '「はじめまして」用于初次见面，「と申します」是「我叫……」的谦逊说法。',
              hint: '初次见面的礼貌表达。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '请多多关照。',
              audio: 'どうぞよろしくお願いします。',
              options: null,
              answer: 'どうぞよろしくお願いします。',
              explanation: '「よろしくお願いします」是自我介绍结束时常用的礼貌客套话。',
              hint: '自我介绍收尾的客套语。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '我来自中国。',
              audio: '私は中国から来ました。',
              options: null,
              answer: '私は中国から来ました。',
              explanation: '「から」表示起点，「中国から来ました」即「来自中国」。',
              hint: '注意助词「から」表示起点。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '我是学生。',
              audio: '私は学生です。',
              options: null,
              answer: '私は学生です。',
              explanation: '「は」提示主题，「です」礼貌结句，构成最基础的自我介绍句型。',
              hint: '最基础的自我介绍句。'
            },
            {
              type: 'mcq',
              prompt: '「はじめまして」はどんな時に使いますか。',
              prompt_translation: '「はじめまして」在什么场合使用？',
              audio: null,
              options: ['初対面の時', '別れる時', '謝る時', '褒める時'],
              answer: '初対面の時',
              explanation: '「はじめまして」意为「初次见面」，用于第一次见面的场合。',
              hint: '第一次见面时使用。'
            }
          ]
        },
        {
          title: '日常听力',
          module: 'listening',
          order_index: 5,
          xp: 20,
          duration_min: 10,
          description: '通过音频辨听日常问候与常见句型。',
          exercises: [
            {
              type: 'listen_choice',
              prompt: '听音频，选择你听到的内容',
              prompt_translation: '',
              audio: 'おはようございます。',
              options: ['おはようございます。', 'こんばんは。', 'ありがとうございます。', 'すみません。'],
              answer: 'おはようございます。',
              explanation: '音频是早晨问候「おはようございます」，注意与「こんばんは（晚上好）」区分。',
              hint: '注意分辨早晨与晚上的问候语。'
            },
            {
              type: 'listen_type',
              prompt: '请听写你听到的句子。',
              prompt_translation: '',
              audio: 'ありがとうございます。',
              options: null,
              answer: 'ありがとうございます。',
              explanation: '听到的是表示感谢的「ありがとうございます」，拼写时注意「ありがとう」的长音。',
              hint: '注意「ありがとう」的长音。'
            },
            {
              type: 'listen_choice',
              prompt: '听音频，选择你听到的内容',
              prompt_translation: '',
              audio: '今日はいい天気ですね。',
              options: ['今日はいい天気ですね。', '明日は雨ですね。', '今日は寒いですね。', '昨日は暑かったです。'],
              answer: '今日はいい天気ですね。',
              explanation: '音频说的是「今天天气真好呢」，关键词是「いい天気」。',
              hint: '注意天气相关的关键词。'
            },
            {
              type: 'listen_type',
              prompt: '请听写你听到的句子。',
              prompt_translation: '',
              audio: 'お元気ですか。',
              options: null,
              answer: 'お元気ですか。',
              explanation: '听到的是询问身体状况的「お元気ですか」，意为「你好吗？」。',
              hint: '询问对方是否安好的问候语。'
            },
            {
              type: 'listen_choice',
              prompt: '听音频，选择你听到的内容',
              prompt_translation: '',
              audio: '電車で会社へ行きます。',
              options: ['電車で会社へ行きます。', 'バスで学校へ行きます。', '車で家へ帰ります。', '歩いて公園へ行きます。'],
              answer: '電車で会社へ行きます。',
              explanation: '音频说的是「坐电车去公司」，「で」表示交通手段。',
              hint: '注意表示交通手段的助词「で」。'
            }
          ]
        }
      ]
    },
    {
      level: 'A2',
      level_order: 2,
      title: '日语进阶',
      subtitle: 'にほんご中級',
      description: '扩展日常词汇，掌握动词活用与观点表达。',
      icon: '🎏',
      lessons: [
        {
          title: '日常生活词汇',
          module: 'vocabulary',
          order_index: 1,
          xp: 20,
          duration_min: 8,
          description: '学习工作与生活中高频出现的常用词汇。',
          exercises: [
            {
              type: 'mcq',
              prompt: '「会社」の読み方はどれですか。',
              prompt_translation: '「会社」的读音是哪一个？',
              audio: null,
              options: ['かいしゃ', 'がいしゃ', 'かいさ', 'かしゃ'],
              answer: 'かいしゃ',
              explanation: '「会社」读作「かいしゃ」，意为「公司」。「社」在此读作「しゃ」。',
              hint: '表示「公司」的词。'
            },
            {
              type: 'mcq',
              prompt: '「経験」の読み方はどれですか。',
              prompt_translation: '「経験」的读音是哪一个？',
              audio: null,
              options: ['けいけん', 'けんけい', 'きょうけん', 'けいかん'],
              answer: 'けいけん',
              explanation: '「経験」读作「けいけん」，意为「经验」。注意音读「けい」和「けん」的顺序。',
              hint: '表示「经验」的词。'
            },
            {
              type: 'fill',
              prompt: '彼は毎日____を書きます。',
              prompt_translation: '他每天写日记。空格处应填什么词？',
              audio: null,
              options: null,
              answer: '日記',
              explanation: '「日記」读作「にっき」，意为「日记」，「日記を書きます」即「写日记」。',
              hint: '「写」的宾语，指每天的记录。'
            },
            {
              type: 'mcq',
              prompt: '「約束」の読み方はどれですか。',
              prompt_translation: '「約束」的读音是哪一个？',
              audio: null,
              options: ['やくそく', 'よやく', 'よてい', 'ようい'],
              answer: 'やくそく',
              explanation: '「約束」读作「やくそく」，意为「约定」；「予約」是「预约」，「予定」是「预定」。',
              hint: '表示「约定」的词。'
            },
            {
              type: 'fill',
              prompt: '会議は三時____始まります。',
              prompt_translation: '会议三点开始。空格处应填哪个助词？',
              audio: null,
              options: null,
              answer: 'に',
              explanation: '「始まります」用「に」标记时间点，「三時に始まります」即「三点开始」。',
              hint: '表示具体时间点的助词。'
            }
          ]
        },
        {
          title: '情感与天气',
          module: 'vocabulary',
          order_index: 2,
          xp: 20,
          duration_min: 8,
          description: '表达情绪与描述天气的常用形容词。',
          exercises: [
            {
              type: 'mcq',
              prompt: '「嬉しい」の意味は何ですか。',
              prompt_translation: '「嬉しい」是什么意思？',
              audio: null,
              options: ['高兴', '悲伤', '生气', '害怕'],
              answer: '高兴',
              explanation: '「嬉しい」读作「うれしい」，表示因好事而「高兴、开心」。',
              hint: '表示开心、喜悦。'
            },
            {
              type: 'mcq',
              prompt: '「悲しい」の反対語はどれですか。',
              prompt_translation: '「悲しい」的反义词是哪一个？',
              audio: null,
              options: ['嬉しい', '楽しい', '寂しい', '怖い'],
              answer: '嬉しい',
              explanation: '「悲しい」意为「悲伤」，其反义词是表示「高兴」的「嬉しい」。',
              hint: '与「悲伤」相反的情绪。'
            },
            {
              type: 'fill',
              prompt: '今日は____が降っています。',
              prompt_translation: '今天正在下雨。空格处应填什么词？',
              audio: null,
              options: null,
              answer: '雨',
              explanation: '「雨」读作「あめ」，意为「雨」，「雨が降っています」即「正在下雨」。',
              hint: '从天空落下的天气现象。'
            },
            {
              type: 'mcq',
              prompt: '「涼しい」はどんな季節によく使いますか。',
              prompt_translation: '「涼しい」常用来形容哪个季节？',
              audio: null,
              options: ['夏', '冬', '春', '秋'],
              answer: '夏',
              explanation: '「涼しい」意为「凉爽」，多用于形容夏天舒适的温度。',
              hint: '形容夏天不闷热的感觉。'
            },
            {
              type: 'fill',
              prompt: '明日は____ですから、傘を持って行きます。',
              prompt_translation: '因为明天会下雨，所以要带伞。空格处应填什么词？',
              audio: null,
              options: null,
              answer: '雨',
              explanation: '「雨ですから」表示原因，即「因为下雨」，所以「带伞去」。',
              hint: '与「伞」搭配的天气。'
            }
          ]
        },
        {
          title: '动词活用',
          module: 'grammar',
          order_index: 3,
          xp: 25,
          duration_min: 10,
          description: '练习动词ます形、て形与过去式的正确使用。',
          exercises: [
            {
              type: 'mcq',
              prompt: '私は毎朝新聞を____。',
              prompt_translation: '我每天早上读报纸。应选哪个形式？',
              audio: null,
              options: ['読みます', '読む', '読んで', '読んだ'],
              answer: '読みます',
              explanation: '句子描述习惯性动作，用现在时的礼貌形「読みます」。',
              hint: '表示习惯性动作的现在时。'
            },
            {
              type: 'fill',
              prompt: '昨日、映画を____。',
              prompt_translation: '昨天看了电影。应填哪个过去式？',
              audio: null,
              options: null,
              answer: '見ました',
              explanation: '「昨日」表示过去，需用「見る」的礼貌过去式「見ました」。',
              hint: '「見る」的礼貌过去式。'
            },
            {
              type: 'mcq',
              prompt: '一緒に____ましょう。',
              prompt_translation: '一起走吧。应选哪个形式？',
              audio: null,
              options: ['行き', '行く', '行って', '行きます'],
              answer: '行き',
              explanation: '「ましょう」前接动词ます形词干，「行きましょう」即「一起走吧」。',
              hint: '「ましょう」前需接ます形词干。'
            },
            {
              type: 'fill',
              prompt: '子供の時、よく公園で____。',
              prompt_translation: '小时候经常在公园玩。应填哪个过去式？',
              audio: null,
              options: null,
              answer: '遊びました',
              explanation: '「子供の時」表示过去，需用「遊ぶ」的礼貌过去式「遊びました」。',
              hint: '「遊ぶ」的礼貌过去式。'
            },
            {
              type: 'mcq',
              prompt: '彼は今、本を____います。',
              prompt_translation: '他现在正在读书。应选哪个形式？',
              audio: null,
              options: ['読んで', '読み', '読む', '読んだ'],
              answer: '読んで',
              explanation: '「～ています」表示动作进行，需用「読む」的て形「読んで」。',
              hint: '「～ています」前需接て形。'
            }
          ]
        },
        {
          title: '表达观点',
          module: 'speaking',
          order_index: 4,
          xp: 25,
          duration_min: 10,
          description: '练习表达赞同、反对与个人意见。',
          exercises: [
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '我赞成这个方案。',
              audio: '私はこの案に賛成です。',
              options: null,
              answer: '私はこの案に賛成です。',
              explanation: '「賛成です」意为「赞成」，「に」标记赞成的对象。',
              hint: '注意「賛成」的用法。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '请告诉我您的意见。',
              audio: 'ご意見を聞かせてください。',
              options: null,
              answer: 'ご意見を聞かせてください。',
              explanation: '「ご意見」是「意見」的敬语，「聞かせてください」意为「请让我听」。',
              hint: '注意敬语「ご～」。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '我觉得那是个好主意。',
              audio: 'それはいいアイデアだと思います。',
              options: null,
              answer: 'それはいいアイデアだと思います。',
              explanation: '「～と思います」表示说话人的想法，「いいアイデア」意为「好主意」。',
              hint: '注意「～と思います」表达想法。'
            },
            {
              type: 'mcq',
              prompt: '「賛成」の反対の言葉はどれですか。',
              prompt_translation: '「賛成」的反义词是哪一个？',
              audio: null,
              options: ['反対', '同意', '意見', '考え'],
              answer: '反対',
              explanation: '「賛成」是「赞成」，其反义词是「反対」，意为「反对」。',
              hint: '与「赞成」相反的态度。'
            },
            {
              type: 'speak',
              prompt: '请跟读这句话。',
              prompt_translation: '请让我再考虑一下。',
              audio: 'もう少し検討させてください。',
              options: null,
              answer: 'もう少し検討させてください。',
              explanation: '「～させてください」是请求对方允许自己做某事，「検討」意为「考虑」。',
              hint: '注意「～させてください」的请求表达。'
            }
          ]
        },
        {
          title: '场景听力',
          module: 'listening',
          order_index: 5,
          xp: 25,
          duration_min: 10,
          description: '听懂问路、乘车等日常场景对话。',
          exercises: [
            {
              type: 'listen_choice',
              prompt: '听音频，选择你听到的内容',
              prompt_translation: '',
              audio: 'すみません、駅はどこですか。',
              options: ['すみません、駅はどこですか。', 'すみません、駅はいつですか。', 'すみません、駅は何ですか。', 'すみません、駅はだれですか。'],
              answer: 'すみません、駅はどこですか。',
              explanation: '音频是问路常用句「请问车站在哪里」，「どこ」表示地点。',
              hint: '注意疑问词「どこ」。'
            },
            {
              type: 'listen_type',
              prompt: '请听写你听到的句子。',
              prompt_translation: '',
              audio: '明日の会議は十時に始まります。',
              options: null,
              answer: '明日の会議は十時に始まります。',
              explanation: '听到的是「明天的会议十点开始」，注意「に」标记时间点。',
              hint: '注意时间「十時」与助词「に」。'
            },
            {
              type: 'listen_choice',
              prompt: '听音频，选择你听到的内容',
              prompt_translation: '',
              audio: 'この電車は東京に行きますか。',
              options: ['この電車は東京に行きますか。', 'この電車は東京に来ますか。', 'この電車は東京です。', 'この電車は東京にありますか。'],
              answer: 'この電車は東京に行きますか。',
              explanation: '音频是询问电车去向「这趟电车去东京吗」，「行きます」表示去往。',
              hint: '注意动词「行きます」。'
            },
            {
              type: 'listen_type',
              prompt: '请听写你听到的句子。',
              prompt_translation: '',
              audio: '私は週末に友達と映画を見ます。',
              options: null,
              answer: '私は週末に友達と映画を見ます。',
              explanation: '听到的是「我周末和朋友看电影」，「と」表示一起行动的对象。',
              hint: '注意助词「と」与「を」。'
            },
            {
              type: 'listen_choice',
              prompt: '听音频，选择你听到的内容',
              prompt_translation: '',
              audio: 'ここで少し休んでください。',
              options: ['ここで少し休んでください。', 'そこで少し休んでください。', 'ここで少し待ってください。', 'ここで少し立ってください。'],
              answer: 'ここで少し休んでください。',
              explanation: '音频是「请在这里休息一会儿」，「休んでください」是「请休息」的て形加请求。',
              hint: '注意动词「休む」的て形。'
            }
          ]
        }
      ]
    }
  ],
  words: [
    { level: 'A1', word: 'こんにちは', reading: 'こんにちは', meaning: '你好', pos: '寒暄语', example: 'こんにちは、田中さん。', example_translation: '你好，田中先生。' },
    { level: 'A1', word: 'ありがとう', reading: 'ありがとう', meaning: '谢谢', pos: '寒暄语', example: '手伝ってくれてありがとう。', example_translation: '谢谢你帮我。' },
    { level: 'A1', word: 'おはよう', reading: 'おはよう', meaning: '早上好', pos: '寒暄语', example: 'おはよう、今日もいい天気だね。', example_translation: '早上好，今天天气也不错呢。' },
    { level: 'A1', word: 'さようなら', reading: 'さようなら', meaning: '再见', pos: '寒暄语', example: 'さようなら、また明日。', example_translation: '再见，明天见。' },
    { level: 'A1', word: '学校', reading: 'がっこう', meaning: '学校', pos: '名词', example: '毎日学校へ行きます。', example_translation: '每天都去学校。' },
    { level: 'A1', word: '先生', reading: 'せんせい', meaning: '老师', pos: '名词', example: '先生はとても優しいです。', example_translation: '老师非常温柔。' },
    { level: 'A1', word: '学生', reading: 'がくせい', meaning: '学生', pos: '名词', example: '私は大学生です。', example_translation: '我是大学生。' },
    { level: 'A1', word: '友達', reading: 'ともだち', meaning: '朋友', pos: '名词', example: '友達と公園で遊びます。', example_translation: '和朋友在公园玩。' },
    { level: 'A1', word: '水', reading: 'みず', meaning: '水', pos: '名词', example: '水を一杯ください。', example_translation: '请给我一杯水。' },
    { level: 'A1', word: '食べる', reading: 'たべる', meaning: '吃', pos: '动词', example: '朝ご飯を食べます。', example_translation: '吃早饭。' },
    { level: 'A1', word: '飲む', reading: 'のむ', meaning: '喝', pos: '动词', example: 'お茶を飲みます。', example_translation: '喝茶。' },
    { level: 'A1', word: '行く', reading: 'いく', meaning: '去', pos: '动词', example: '明日、東京へ行きます。', example_translation: '明天去东京。' },
    { level: 'A1', word: '来る', reading: 'くる', meaning: '来', pos: '动词', example: '友達が家に来ます。', example_translation: '朋友来我家。' },
    { level: 'A1', word: '見る', reading: 'みる', meaning: '看', pos: '动词', example: 'テレビを見ます。', example_translation: '看电视。' },
    { level: 'A1', word: '大きい', reading: 'おおきい', meaning: '大的', pos: '形容词', example: 'この犬は大きいです。', example_translation: '这只狗很大。' },
    { level: 'A1', word: '小さい', reading: 'ちいさい', meaning: '小的', pos: '形容词', example: '小さい猫がいます。', example_translation: '有一只小猫。' },
    { level: 'A1', word: '新しい', reading: 'あたらしい', meaning: '新的', pos: '形容词', example: '新しい靴を買いました。', example_translation: '买了新鞋。' },
    { level: 'A1', word: '毎日', reading: 'まいにち', meaning: '每天', pos: '名词', example: '毎日日本語を勉強します。', example_translation: '每天学习日语。' },
    { level: 'A2', word: '経験', reading: 'けいけん', meaning: '经验', pos: '名词', example: '彼は豊富な経験があります。', example_translation: '他有丰富的经验。' },
    { level: 'A2', word: '約束', reading: 'やくそく', meaning: '约定', pos: '名词', example: '友達と約束をしました。', example_translation: '和朋友约好了。' },
    { level: 'A2', word: '会議', reading: 'かいぎ', meaning: '会议', pos: '名词', example: '会議は三時に始まります。', example_translation: '会议三点开始。' },
    { level: 'A2', word: '準備', reading: 'じゅんび', meaning: '准备', pos: '名词', example: '旅行の準備をしています。', example_translation: '正在准备旅行。' },
    { level: 'A2', word: '説明', reading: 'せつめい', meaning: '说明', pos: '名词', example: '先生が問題を説明します。', example_translation: '老师讲解问题。' },
    { level: 'A2', word: '賛成', reading: 'さんせい', meaning: '赞成', pos: '名词', example: '私はその案に賛成です。', example_translation: '我赞成那个方案。' },
    { level: 'A2', word: '反対', reading: 'はんたい', meaning: '反对', pos: '名词', example: '彼はその計画に反対しました。', example_translation: '他反对那个计划。' },
    { level: 'A2', word: '意見', reading: 'いけん', meaning: '意见', pos: '名词', example: 'ご意見を聞かせてください。', example_translation: '请告诉我您的意见。' },
    { level: 'A2', word: '天気', reading: 'てんき', meaning: '天气', pos: '名词', example: '明日はいい天気になるでしょう。', example_translation: '明天天气会变好吧。' },
    { level: 'A2', word: '雨', reading: 'あめ', meaning: '雨', pos: '名词', example: '午後から雨が降ります。', example_translation: '下午开始下雨。' },
    { level: 'A2', word: '雪', reading: 'ゆき', meaning: '雪', pos: '名词', example: '子供たちが雪で遊んでいます。', example_translation: '孩子们在玩雪。' },
    { level: 'A2', word: '暑い', reading: 'あつい', meaning: '炎热的', pos: '形容词', example: '今日はとても暑いです。', example_translation: '今天非常热。' },
    { level: 'A2', word: '寒い', reading: 'さむい', meaning: '寒冷的', pos: '形容词', example: '寒いからコートを着ます。', example_translation: '因为冷，所以穿大衣。' },
    { level: 'A2', word: '涼しい', reading: 'すずしい', meaning: '凉爽的', pos: '形容词', example: '夏は涼しい風が吹きます。', example_translation: '夏天吹着凉爽的风。' },
    { level: 'A2', word: '嬉しい', reading: 'うれしい', meaning: '高兴的', pos: '形容词', example: '合格して嬉しいです。', example_translation: '合格了很高兴。' },
    { level: 'A2', word: '悲しい', reading: 'かなしい', meaning: '悲伤的', pos: '形容词', example: 'その知らせを聞いて悲しいです。', example_translation: '听到那个消息很伤心。' },
    { level: 'A2', word: '考える', reading: 'かんがえる', meaning: '思考', pos: '动词', example: 'よく考えてから決めます。', example_translation: '好好考虑之后再决定。' },
    { level: 'A2', word: '続ける', reading: 'つづける', meaning: '继续', pos: '动词', example: '毎日運動を続けます。', example_translation: '每天坚持运动。' }
  ]
};
