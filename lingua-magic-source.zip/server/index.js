'use strict';

/** 服务入口：HTTP 服务 + API 路由分发 + 静态资源 */

const origEmitWarning = process.emitWarning;
process.emitWarning = (warning, ...rest) => {
  const name = typeof warning === 'object' ? warning.name : rest[0];
  if (name === 'ExperimentalWarning') return;
  return origEmitWarning.call(process, warning, ...rest);
};

const http = require('node:http');
const path = require('node:path');

const { ensureSeed } = require('./db');
const { matchRoute, sendJson, readBody, serveStatic, HttpError } = require('./http');
const A = require('./auth');
require('./routes');
require('./routes_lingua');
const { seedDemoContent } = require('./demo');

const PORT = Number(process.env.PORT || 5173);
const PUBLIC_DIR = path.join(__dirname, '..', 'public');

const seedInfo = ensureSeed();
const demoInfo = seedDemoContent();

function log(...args) {
  process.stdout.write(args.join(' ') + '\n');
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;
  const query = Object.fromEntries(url.searchParams.entries());

  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');

  if (req.method === 'OPTIONS') {
    res.writeHead(204).end();
    return;
  }

  if (!pathname.startsWith('/api/')) {
    if (pathname === '/health') {
      sendJson(res, 200, { ok: true, uptime: process.uptime() });
      return;
    }
    if (serveStatic(PUBLIC_DIR, pathname, res)) return;
    // SPA 兜底
    if (serveStatic(PUBLIC_DIR, '/index.html', res)) return;
    res.writeHead(404).end('Not Found');
    return;
  }

  try {
    const m = matchRoute(req.method, pathname);
    if (!m) throw new HttpError(404, `接口不存在：${pathname}`);
    if (m.methodMismatch) throw new HttpError(405, `${pathname} 不支持 ${req.method}`);

    let body = {};
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) body = await readBody(req);

    const ctx = { req, res, params: m.params, query, body, user: null };
    if (m.auth) {
      const user = A.userFromToken(A.bearerToken(req));
      if (!user) throw new HttpError(401, '登录已过期，请重新登录');
      ctx.user = user;
    }
    const out = await m.handler(ctx);
    sendJson(res, 200, out);
  } catch (err) {
    const status = err instanceof HttpError ? err.status : (err.status || 500);
    if (status >= 500) log('[error]', err.stack || err.message);
    sendJson(res, status, { error: err.message || '服务器内部错误' });
  }
});

server.listen(PORT, () => {
  log(`\n  🌍  沉浸式多语种学习平台已启动`);
  log(`  →  http://localhost:${PORT}`);
  log(`  →  种子数据：${seedInfo.seeded ? `已导入 ${seedInfo.languages} 门语言` : `沿用现有数据（${seedInfo.languages} 门语言）`} · 言灵短语 ${seedInfo.phrases} 条`);
  if (demoInfo.seeded) log(`  →  社区示例：已注入 ${demoInfo.users} 位用户 / ${demoInfo.posts} 条帖子`);
  log('');
});

process.on('SIGINT', () => { server.close(() => process.exit(0)); });
