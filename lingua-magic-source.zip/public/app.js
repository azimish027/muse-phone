/* ==========================================================================
   Lingua · 沉浸式多语种学习平台 —— 前端应用（原生 SPA，无构建依赖）
   ========================================================================== */
(function () {
  'use strict';

  const TOKEN_KEY = 'lingua_token';
  const MODULE_LABEL = {
    vocabulary: '单词记忆', grammar: '语法练习', speaking: '口语跟读', listening: '听力训练',
  };
  const MODULE_ICON = {
    vocabulary: '🧠', grammar: '🧩', speaking: '🗣️', listening: '👂',
  };
  const LANG_LABEL = { en: '英语', ja: '日语', ko: '韩语', zh: '中文' };

  const app = document.getElementById('app');
  const toastHost = document.getElementById('toast');
  const modalHost = document.getElementById('modal');

  const state = {
    user: null,
    words: [],
    route: '',
    meta: { title: '', sub: '' },
    reviewCount: 0,
  };

  /* ---------------------------------------------------------------- 基础工具 */

  const esc = (s) => String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

  const qs = (sel, root = document) => root.querySelector(sel);
  const qsa = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function getToken() { return localStorage.getItem(TOKEN_KEY) || ''; }
  function setToken(t) { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); }

  async function api(path, method = 'GET', body) {
    const headers = {};
    const token = getToken();
    if (token) headers.Authorization = 'Bearer ' + token;
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data = null;
    try { data = await res.json(); } catch { /* ignore */ }
    if (!res.ok) {
      if (res.status === 401) { setToken(''); state.user = null; }
      throw new Error((data && data.error) || `请求失败（${res.status}）`);
    }
    return data;
  }

  function toast(msg, kind = '') {
    const node = document.createElement('div');
    node.className = 'toast ' + kind;
    node.innerHTML = `<span>${esc(msg)}</span>`;
    toastHost.appendChild(node);
    setTimeout(() => {
      node.style.transition = 'opacity .3s, transform .3s';
      node.style.opacity = '0';
      node.style.transform = 'translateX(18px)';
      setTimeout(() => node.remove(), 320);
    }, 2800);
  }

  function openModal(html, onMount) {
    modalHost.hidden = false;
    modalHost.innerHTML = `<div class="modal-backdrop" data-close="1"></div>
      <div class="modal-card">
        <button class="btn btn-sm btn-ghost modal-close" data-close="1">✕</button>
        ${html}
      </div>`;
    qsa('[data-close]', modalHost).forEach((n) => n.addEventListener('click', closeModal));
    if (onMount) onMount(qs('.modal-card', modalHost));
  }
  function closeModal() { modalHost.hidden = true; modalHost.innerHTML = ''; }

  function timeAgo(iso) {
    const diff = (Date.now() - new Date(iso).getTime()) / 1000;
    if (diff < 60) return '刚刚';
    if (diff < 3600) return Math.floor(diff / 60) + ' 分钟前';
    if (diff < 86400) return Math.floor(diff / 3600) + ' 小时前';
    if (diff < 86400 * 30) return Math.floor(diff / 86400) + ' 天前';
    return new Date(iso).toLocaleDateString('zh-CN');
  }

  function initials(name) { return String(name || '?').trim().slice(0, 2).toUpperCase(); }

  function avatar(user, size = 38) {
    const color = user.avatar_color || '#6366f1';
    const s = size ? `width:${size}px;height:${size}px;flex:0 0 ${size}px;font-size:${size * 0.36}px` : '';
    return `<div class="avatar" style="background:${color};${s}">${esc(initials(user.nickname))}</div>`;
  }

  /* ---------------------------------------------------------------- 语音能力 */

  let voices = [];
  function refreshVoices() { try { voices = window.speechSynthesis.getVoices() || []; } catch { voices = []; } }
  if ('speechSynthesis' in window) {
    refreshVoices();
    window.speechSynthesis.onvoiceschanged = refreshVoices;
  }

  function pickVoice(lang) {
    const want = String(lang || 'en-US').toLowerCase();
    const base = want.slice(0, 2);
    return voices.find((v) => v.lang.replace('_', '-').toLowerCase() === want)
      || voices.find((v) => v.lang.replace('_', '-').toLowerCase().startsWith(base))
      || null;
  }

  /** 朗读文本；返回 Promise，在朗读结束时 resolve */
  function speak(text, lang) {
    if (!('speechSynthesis' in window)) {
      toast('当前浏览器不支持语音朗读，请使用 Chrome / Edge', 'no');
      return Promise.resolve();
    }
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(text || ''));
    u.lang = lang || 'en-US';
    const v = pickVoice(u.lang);
    if (v) u.voice = v;
    u.rate = 0.92;
    u.pitch = 1;
    return new Promise((resolve) => {
      u.onend = () => resolve();
      u.onerror = () => resolve();
      window.speechSynthesis.speak(u);
    });
  }

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  /** 文本规范化，用于跟读评分 */
  function normalizeText(str, lang) {
    let s = String(str || '').toLowerCase().trim();
    if (['ja', 'ko', 'zh'].includes(lang)) {
      return s.replace(/[\s\u3000、。！？，・.,!?'"“”‘’…—\-·:;()（）\[\]]/g, '');
    }
    return s.replace(/[^a-z0-9\s']/g, '').replace(/\s+/g, ' ').trim();
  }

  /** 相似度 0~1（基于编辑距离） */
  function similarity(a, b) {
    if (!a && !b) return 1;
    if (!a || !b) return 0;
    const m = a.length, n = b.length;
    if (Math.abs(m - n) / Math.max(m, n) > 0.75) return 0;
    const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
        );
      }
    }
    return 1 - dp[m][n] / Math.max(m, n);
  }

  function answerVariants(answer) {
    return String(answer || '').split(/\s*[|/]\s*/).map((s) => s.trim()).filter(Boolean);
  }

  function checkAnswer(input, answer, lang) {
    const target = answerVariants(answer);
    const given = normalizeText(input, lang);
    if (!given) return false;
    return target.some((t) => {
      const n = normalizeText(t, lang);
      return n === given || (n.length > 3 && similarity(n, given) >= 0.9);
    });
  }

  /* ---------------------------------------------------------------- 路由 */

  function navigate(hash) {
    if (location.hash === hash) render();
    else location.hash = hash;
  }

  function parseRoute() {
    const raw = location.hash.replace(/^#\/?/, '');
    const parts = raw.split('/').filter(Boolean);
    return { name: parts[0] || 'home', param: parts[1] || null, parts };
  }

  window.addEventListener('hashchange', () => render());

  /* ---------------------------------------------------------------- 外壳 */

  const NAV = [
    { id: 'home', icon: '🏠', label: '首页', title: '今日学习', sub: '个性化路径为你安排好了今天的任务' },
    { id: 'courses', icon: '📚', label: '课程', title: '分级课程', sub: '英语 · 日语 · 韩语，从 A1 到 B1 循序渐进' },
    { id: 'review', icon: '🔁', label: '复习', title: '单词复习', sub: '基于遗忘曲线的间隔重复记忆' },
    { id: 'community', icon: '💬', label: '社区', title: '学习社区', sub: '和同伴交流经验、互相激励' },
    { id: 'achievements', icon: '🏆', label: '成就', title: '成就殿堂', sub: '记录你的每一个里程碑' },
    { id: 'profile', icon: '👤', label: '我的', title: '个人中心', sub: '学习数据与偏好设置' },
  ];

  function shell(viewHtml) {
    const u = state.user;
    const stats = u.stats;
    const pct = Math.round((stats.levelProgress || 0) * 100);
    const active = state.route;
    const navHtml = NAV.map((n) => {
      const on = n.id === active || (active === 'course' && n.id === 'courses')
        || (active === 'lesson' && n.id === 'courses') || (active === 'post' && n.id === 'community');
      const badge = n.id === 'review' && state.reviewCount > 0
        ? `<span class="badge">${state.reviewCount}</span>` : '';
      return `<a class="nav-item ${on ? 'on' : ''}" href="#/${n.id}">
        <span class="ni">${n.icon}</span><span class="label">${n.label}</span>${badge}</a>`;
    }).join('');

    app.innerHTML = `
      <div class="shell">
        <aside class="sidebar">
          <div class="brand-mark"><span class="dot">🌍</span><span>Lingua</span></div>
          <nav class="nav">${navHtml}</nav>
          <div class="sidebar-foot">
            <div class="user-chip" data-nav="#/profile">
              ${avatar(u)}
              <div>
                <div class="u-name">${esc(u.nickname)}</div>
                <div class="u-sub">Lv.${stats.level} ${esc(stats.levelTitle)}</div>
              </div>
            </div>
          </div>
        </aside>
        <main class="main">
          <header class="topbar">
            <div>
              <h1>${esc(state.meta.title)}</h1>
              <div class="sub">${esc(state.meta.sub)}</div>
            </div>
            <div class="topbar-spacer"></div>
            <div class="stat-chips">
              <div class="stat-chip xp" title="累计经验值">⭐ <span class="v">${stats.xp}</span> XP</div>
              <div class="stat-chip flame" title="连续学习天数">🔥 <span class="v">${stats.streak}</span> 天</div>
              <div class="stat-chip hide-sm" title="累计学习时长">⏱ <span class="v">${Math.round(stats.total_minutes)}</span> 分钟</div>
            </div>
            <div class="level-ring" style="--p:${pct}" title="等级进度 ${pct}%">
              <span>Lv.${stats.level}</span>
            </div>
          </header>
          <div class="view" id="view">${viewHtml}</div>
        </main>
      </div>`;
  }

  function setView(html) { const v = document.getElementById('view'); if (v) v.innerHTML = html; }

  /* ---------------------------------------------------------------- 登录 / 注册 */

  let authMode = 'login';

  function renderAuth() {
    app.innerHTML = `
      <div class="auth-wrap">
        <section class="auth-hero">
          <div class="brand-mark"><span class="dot">🌍</span><span>Lingua</span></div>
          <div>
            <h1 class="hero-title">用<b>沉浸式</b>的方式<br/>真正<em>开口说</em>一门语言</h1>
            <p class="hero-sub">分级课程体系 + 四大互动学习模块 + 个性化路径推荐，让英语、日语、韩语的学习像游戏一样上瘾。</p>
            <ul class="hero-points">
              <li><span class="ico">📚</span><div><b>分级课程体系</b><br/>A1 → B1 阶梯式进阶，每节课 5 分钟</div></li>
              <li><span class="ico">🧠</span><div><b>四大互动模块</b><br/>单词记忆 · 语法练习 · 口语跟读 · 听力训练</div></li>
              <li><span class="ico">📈</span><div><b>进度追踪与推荐</b><br/>学习热力图 + AI 个性化每日路径</div></li>
              <li><span class="ico">🏆</span><div><b>社区与成就激励</b><br/>连续打卡、成就徽章、学习排行榜</div></li>
            </ul>
          </div>
          <div class="lang-chips">
            <span class="lang-chip on">🇬🇧 英语</span>
            <span class="lang-chip on">🇯🇵 日语</span>
            <span class="lang-chip on">🇰🇷 韩语</span>
          </div>
        </section>
        <section class="auth-panel">
          <div class="auth-card">
            <div class="auth-tabs">
              <button data-mode="login" class="${authMode === 'login' ? 'on' : ''}">登录</button>
              <button data-mode="register" class="${authMode === 'register' ? 'on' : ''}">注册</button>
            </div>
            <div id="auth-fields"></div>
            <div class="form-error" id="auth-error"></div>
            <button class="btn btn-primary btn-block btn-lg" id="auth-submit">
              ${authMode === 'login' ? '进入学习空间' : '创建账号并开始学习'}
            </button>
            <p class="form-hint">演示账号：<b>linxiaoyu@example.com</b> / <b>demo1234</b></p>
          </div>
        </section>
      </div>`;

    renderAuthFields();

    qsa('[data-mode]', app).forEach((b) => b.addEventListener('click', () => {
      authMode = b.dataset.mode;
      renderAuth();
    }));

    qs('#auth-submit', app).addEventListener('click', submitAuth);
    qs('#auth-fields', app).addEventListener('keydown', (e) => { if (e.key === 'Enter') submitAuth(); });
  }

  function renderAuthFields() {
    const box = qs('#auth-fields', app);
    if (authMode === 'login') {
      box.innerHTML = `
        <div class="field"><label>邮箱</label>
          <input class="input" id="f-email" type="email" placeholder="you@example.com" autocomplete="email" /></div>
        <div class="field"><label>密码</label>
          <input class="input" id="f-password" type="password" placeholder="至少 6 位" autocomplete="current-password" /></div>`;
    } else {
      box.innerHTML = `
        <div class="field"><label>昵称</label>
          <input class="input" id="f-nickname" placeholder="给自己起个名字" /></div>
        <div class="field"><label>邮箱</label>
          <input class="input" id="f-email" type="email" placeholder="you@example.com" autocomplete="email" /></div>
        <div class="field"><label>密码</label>
          <input class="input" id="f-password" type="password" placeholder="至少 6 位" autocomplete="new-password" /></div>`;
    }
  }

  async function submitAuth() {
    const errBox = qs('#auth-error', app);
    errBox.textContent = '';
    const btn = qs('#auth-submit', app);
    const email = (qs('#f-email', app) || {}).value || '';
    const password = (qs('#f-password', app) || {}).value || '';
    const nickname = (qs('#f-nickname', app) || {}).value || '';
    btn.disabled = true;
    btn.textContent = '处理中…';
    try {
      const payload = authMode === 'login'
        ? { email, password }
        : { email, password, nickname };
      const out = await api('/api/auth/' + authMode, 'POST', payload);
      setToken(out.token);
      state.user = out.user;
      toast(authMode === 'login' ? `欢迎回来，${out.user.nickname}` : '注册成功，开始你的语言之旅！', 'ok');
      navigate(out.user.profile.onboarded ? '#/home' : '#/onboarding');
    } catch (e) {
      errBox.textContent = e.message;
      btn.disabled = false;
      btn.textContent = authMode === 'login' ? '进入学习空间' : '创建账号并开始学习';
    }
  }

  /* ---------------------------------------------------------------- 新手引导 */

  const LANG_META = {
    en: { name: '英语', flag: '🇬🇧' },
    ja: { name: '日语', flag: '🇯🇵' },
    ko: { name: '韩语', flag: '🇰🇷' },
  };

  function renderOnboarding() {
    const p = state.user.profile;
    const chosen = new Set(p.target_langs && p.target_langs.length ? p.target_langs : ['en']);
    app.innerHTML = `
      <div class="auth-wrap" style="grid-template-columns:1fr">
        <section class="auth-panel">
          <div class="auth-card" style="width:min(560px,94vw)">
            <h2 style="margin:0 0 6px">定制你的学习方案</h2>
            <p class="card-sub" style="margin-bottom:22px">选择想学的语言与当前水平，系统会据此推荐每日学习路径。</p>

            <div class="field">
              <label>我想学习（可多选）</label>
              <div class="tabs" id="ob-langs">
                ${Object.entries(LANG_META).map(([code, m]) =>
                  `<button class="tab ${chosen.has(code) ? 'on' : ''}" data-lang="${code}">${m.flag} ${m.name}</button>`).join('')}
              </div>
            </div>
            <div class="field">
              <label>我的水平</label>
              <select class="select" id="ob-level">
                ${['A1', 'A2', 'B1', 'B2'].map((l) =>
                  `<option value="${l}" ${p.placement === l ? 'selected' : ''}>${l} · ${
                    { A1: '零基础 / 入门', A2: '能简单交流', B1: '能日常对话', B2: '能深入讨论' }[l]}</option>`).join('')}
              </select>
            </div>
            <div class="field">
              <label>每日学习目标</label>
              <select class="select" id="ob-goal">
                ${[10, 20, 30, 45, 60].map((g) =>
                  `<option value="${g}" ${(p.daily_goal_min || 20) === g ? 'selected' : ''}>${g} 分钟 / 天</option>`).join('')}
              </select>
            </div>
            <button class="btn btn-primary btn-block btn-lg" id="ob-submit" style="margin-top:8px">开始沉浸式学习</button>
          </div>
        </section>
      </div>`;

    qsa('#ob-langs .tab', app).forEach((b) => b.addEventListener('click', () => {
      const code = b.dataset.lang;
      if (chosen.has(code)) { if (chosen.size > 1) chosen.delete(code); }
      else chosen.add(code);
      b.classList.toggle('on', chosen.has(code));
    }));

    qs('#ob-submit', app).addEventListener('click', async () => {
      try {
        const out = await api('/api/profile/onboarding', 'POST', {
          target_langs: [...chosen],
          placement: qs('#ob-level', app).value,
          daily_goal_min: Number(qs('#ob-goal', app).value),
        });
        state.user = out.user;
        toast('方案已生成，开始今天的学习吧！', 'ok');
        navigate('#/home');
      } catch (e) { toast(e.message, 'no'); }
    });
  }

  /* ---------------------------------------------------------------- 首页仪表盘 */

  async function renderHome() {
    state.meta = NAV[0];
    setView('<div class="empty"><span class="ico">⏳</span>正在生成今日学习路径…</div>');
    const [path, prog] = await Promise.all([
      api('/api/path/today'),
      api('/api/progress/overview'),
    ]);
    state.reviewCount = path.goal ? (path.tasks.find((t) => t.kind === 'review') || {}).count || 0 : 0;
    state.user.stats = { ...state.user.stats, ...path.stats };
    refreshShellChrome();

    const u = state.user;
    const t = prog.today;
    const s = prog.stats;

    const taskHtml = path.tasks.length ? path.tasks.map((task) => `
      <div class="plan-item" data-nav="${esc(task.href)}">
        <div class="pi">${task.icon}</div>
        <div style="flex:1">
          <div class="pt">${esc(task.title)}</div>
          ${task.subtitle ? `<div class="pr">${esc(task.subtitle)}</div>` : ''}
          <div class="pr" style="margin-top:4px;color:var(--text-faint)">${esc(task.reason)}</div>
          <div class="pm"><span>⏱ 约 ${task.minutes} 分钟</span><span>⭐ +${task.xp} XP</span>
            ${task.moduleLabel ? `<span>${MODULE_ICON[task.module] || ''} ${esc(task.moduleLabel)}</span>` : ''}</div>
        </div>
        <div class="go">›</div>
      </div>`).join('') : `<div class="empty"><span class="ico">🎉</span>今天的任务都完成啦，明天继续！</div>`;

    const langHtml = prog.languages.length ? prog.languages.map((l) => `
      <div class="row" style="gap:14px">
        <div style="font-size:1.5rem">${l.flag}</div>
        <div style="flex:1">
          <div class="row" style="justify-content:space-between">
            <span style="font-weight:640">${esc(l.name)}</span>
            <span style="font-size:.78rem;color:var(--text-faint)">${l.completed}/${l.total} 课</span>
          </div>
          <div class="progress thin" style="margin-top:7px"><i style="width:${l.percent}%"></i></div>
        </div>
      </div>`).join('') : '<div class="card-sub">还没有学习记录，去课程页开始第一节课吧。</div>';

    const modHtml = prog.modules.map((m) => `
      <div style="margin-bottom:14px">
        <div class="row" style="justify-content:space-between;margin-bottom:6px">
          <span style="font-size:.86rem">${MODULE_ICON[m.module]} ${esc(m.label)}</span>
          <span style="font-size:.78rem;color:var(--text-faint)">
            ${m.accuracy === null ? '暂无数据' : `准确率 ${m.accuracy}%`} · 完成 ${m.lessons} 课</span>
        </div>
        <div class="progress thin ${m.module === 'speaking' ? 'gold' : m.module === 'listening' ? 'cool' : 'green'}">
          <i style="width:${m.accuracy === null ? 0 : m.accuracy}%"></i></div>
      </div>`).join('');

    const heat = prog.days.map((d) => {
      const lvl = d.minutes >= 30 ? 'l4' : d.minutes >= 15 ? 'l3' : d.minutes >= 5 ? 'l2' : d.minutes > 0 ? 'l1' : '';
      return `<div class="heat-cell ${lvl}" title="${d.date} · ${d.minutes} 分钟 · ${d.xp} XP"></div>`;
    }).join('');

    setView(`
      <div class="stack">
        <div class="grid cols-2" style="align-items:start">
          <div class="card pad-lg">
            <div class="section-head">
              <h2>今日路径</h2>
              <div class="spacer"></div>
              <span class="pill brand">✨ 个性化推荐</span>
            </div>
            <p class="card-sub" style="margin-bottom:16px">${esc(path.motivation)}</p>
            <div class="stack" style="gap:12px">${taskHtml}</div>
          </div>

          <div class="stack">
            <div class="card pad-lg" style="text-align:center">
              <div class="goal-ring" style="--p:${t.goalPercent}">
                <div class="inner"><b>${t.minutes}<small style="font-size:.9rem">′</small></b><span>/ ${t.goal} 分钟</span></div>
              </div>
              <div style="margin-top:16px">
                <div class="card-title" style="justify-content:center">今日目标 ${t.goalPercent}%</div>
                <p class="card-sub">${t.sessions ? `已完成 ${t.sessions} 次训练 · 获得 ${t.xp} XP` : '还没开始，从上面的任务挑一个吧'}</p>
              </div>
            </div>
            <div class="card">
              <div class="grid cols-2" style="gap:14px">
                <div class="metric"><span class="k">连续打卡</span><span class="v">${s.streak}<small>天</small></span></div>
                <div class="metric"><span class="k">最高连续</span><span class="v">${s.best_streak}<small>天</small></span></div>
                <div class="metric"><span class="k">完成课节</span><span class="v">${prog.totals.lessonsCompleted}<small>节</small></span></div>
                <div class="metric"><span class="k">已掌握单词</span><span class="v">${prog.totals.wordsMastered}<small>个</small></span></div>
              </div>
            </div>
          </div>
        </div>

        <div class="grid cols-2">
          <div class="card pad-lg">
            <div class="section-head"><h2>学习热力图</h2><div class="spacer"></div><span class="card-sub">最近 30 天</span></div>
            <div class="heatmap">${heat}</div>
            <div class="heat-legend">
              <span>少</span>
              <i style="background:rgba(255,255,255,.055)"></i>
              <i style="background:rgba(99,102,241,.34)"></i>
              <i style="background:rgba(99,102,241,.58)"></i>
              <i style="background:rgba(139,92,246,.78)"></i>
              <i style="background:linear-gradient(135deg,#8b5cf6,#ec4899)"></i>
              <span>多</span>
            </div>
          </div>

          <div class="card pad-lg">
            <div class="section-head"><h2>四项能力</h2><div class="spacer"></div><span class="card-sub">沉浸式均衡训练</span></div>
            ${modHtml}
            <div class="divider"></div>
            <div class="card-sub">今日待复习 <b style="color:var(--text)">${prog.totals.wordsDue}</b> 个单词，
              共有 <b style="color:var(--text)">${prog.totals.wordsTotal}</b> 个单词在记忆库中。</div>
            <button class="btn btn-cool btn-block" style="margin-top:14px" data-nav="#/review">开始复习</button>
          </div>
        </div>

        <div class="grid cols-2">
          <div class="card pad-lg">
            <div class="section-head"><h2>语言进度</h2></div>
            <div class="stack" style="gap:16px">${langHtml}</div>
            <button class="btn btn-block" style="margin-top:18px" data-nav="#/courses">浏览全部课程</button>
          </div>
          <div class="card pad-lg" id="home-community">
            <div class="section-head"><h2>社区动态</h2><div class="spacer"></div>
              <span class="pill cyan">共学更有动力</span></div>
            <div id="home-posts"><div class="card-sub">加载中…</div></div>
            <button class="btn btn-block" style="margin-top:14px" data-nav="#/community">进入社区</button>
          </div>
        </div>
      </div>`);

    try {
      const posts = await api('/api/community/posts?limit=3');
      const box = qs('#home-posts');
      if (box) {
        box.innerHTML = posts.posts.map((p) => `
          <div class="plan-item" data-nav="#/post/${p.id}" style="margin-bottom:10px">
            ${avatar({ nickname: p.author, avatar_color: p.avatar_color }, 36)}
            <div style="flex:1;min-width:0">
              <div class="pt" style="font-size:.94rem">${esc(p.title)}</div>
              <div class="pm"><span>${esc(p.author)}</span><span>❤ ${p.likes}</span><span>💬 ${p.comments}</span>
                <span>${timeAgo(p.created_at)}</span></div>
            </div>
          </div>`).join('') || '<div class="card-sub">还没有动态，来发第一条吧。</div>';
      }
    } catch { /* ignore */ }
  }

  function refreshShellChrome() {
    const s = state.user.stats;
    const ring = qs('.level-ring');
    if (ring) {
      ring.style.setProperty('--p', Math.round((s.levelProgress || 0) * 100));
      qs('span', ring).textContent = 'Lv.' + s.level;
    }
    const chips = qsa('.stat-chip .v');
    if (chips[0]) chips[0].textContent = s.xp;
    if (chips[1]) chips[1].textContent = s.streak;
    if (chips[2]) chips[2].textContent = Math.round(s.total_minutes);
  }

  /* ---------------------------------------------------------------- 课程列表 */

  let courseFilter = 'all';

  async function renderCourses() {
    state.meta = NAV[1];
    setView('<div class="empty"><span class="ico">⏳</span>加载课程…</div>');
    const { languages } = await api('/api/languages');
    const { courses } = await api('/api/courses');

    const tabs = [`<button class="tab ${courseFilter === 'all' ? 'on' : ''}" data-lang="all">全部语言</button>`]
      .concat(languages.map((l) =>
        `<button class="tab ${courseFilter === l.code ? 'on' : ''}" data-lang="${l.code}">${l.flag} ${esc(l.name)}</button>`)).join('');

    const visible = courseFilter === 'all' ? courses : courses.filter((c) => c.lang === courseFilter);
    const byLang = {};
    visible.forEach((c) => { (byLang[c.lang] = byLang[c.lang] || []).push(c); });

    const groups = Object.entries(byLang).map(([code, list]) => {
      const meta = languages.find((l) => l.code === code) || {};
      return `
        <div class="stack">
          <div class="section-head">
            <h2>${meta.flag || ''} ${esc(meta.name || code)}</h2>
            <div class="spacer"></div>
            <span class="card-sub">${esc(meta.intro || '')}</span>
          </div>
          <div class="grid cols-3">
            ${list.map((c) => `
              <div class="card hover course-card" data-nav="#/course/${c.id}">
                <div class="row">
                  <span class="level-tag ${String(c.level).toLowerCase()}">${esc(c.level)}</span>
                  <div style="font-size:1.4rem">${c.icon || '📘'}</div>
                  <div class="spacer"></div>
                  <span class="pill">${c.lessons} 节课</span>
                </div>
                <div>
                  <div class="card-title">${esc(c.title)}</div>
                  <div class="card-sub" style="font-style:italic">${esc(c.subtitle || '')}</div>
                </div>
                <p class="card-sub">${esc(c.description || '')}</p>
                <div>
                  <div class="row" style="justify-content:space-between;font-size:.76rem;color:var(--text-faint);margin-bottom:6px">
                    <span>学习进度</span><span>${c.percent}%</span>
                  </div>
                  <div class="progress thin"><i style="width:${c.percent}%"></i></div>
                </div>
              </div>`).join('')}
          </div>
        </div>`;
    }).join('');

    setView(`
      <div class="stack">
        <div class="tabs" id="course-tabs">${tabs}</div>
        ${groups || '<div class="empty"><span class="ico">📭</span>该语言暂无课程</div>'}
      </div>`);

    qsa('#course-tabs .tab').forEach((b) => b.addEventListener('click', () => {
      courseFilter = b.dataset.lang;
      renderCourses();
    }));
  }

  /* ---------------------------------------------------------------- 课程详情 */

  async function renderCourseDetail(id) {
    state.meta = { title: '课程详情', sub: '按顺序完成课节，巩固每一项能力' };
    setView('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
    const data = await api('/api/courses/' + id);
    const { course, lessons } = data;

    const done = lessons.filter((l) => l.status === 'completed').length;
    const pct = lessons.length ? Math.round((done / lessons.length) * 100) : 0;

    setView(`
      <div class="stack" style="max-width:920px;margin:0 auto">
        <a class="btn btn-sm btn-ghost" href="#/courses" style="align-self:flex-start">‹ 返回课程列表</a>
        <div class="card pad-lg">
          <div class="row">
            <span class="level-tag ${String(course.level).toLowerCase()}">${esc(course.level)}</span>
            <div style="font-size:1.8rem">${course.icon || '📘'}</div>
            <div>
              <h2 style="margin:0;font-size:1.35rem">${esc(course.title)}</h2>
              <div class="card-sub">${esc(course.subtitle || '')}</div>
            </div>
            <div class="spacer"></div>
            <span class="pill brand">${done}/${lessons.length} 已完成</span>
          </div>
          <p class="card-sub" style="margin-top:14px">${esc(course.description || '')}</p>
          <div class="progress" style="margin-top:16px"><i style="width:${pct}%"></i></div>
        </div>
        <div class="stack" style="gap:10px">
          ${lessons.map((l) => `
            <div class="lesson-item ${l.status === 'completed' ? 'done' : ''}" data-nav="#/lesson/${l.id}">
              <div class="idx">${l.status === 'completed' ? '✓' : l.order_index}</div>
              <div style="flex:1;min-width:0">
                <div class="lt">${esc(l.title)}</div>
                <div class="ls">
                  <span>${MODULE_ICON[l.module] || ''} ${esc(l.moduleLabel)}</span>
                  <span>⏱ ${l.duration_min} 分钟</span>
                  <span>⭐ ${l.xp} XP</span>
                  <span>${l.exerciseCount} 题</span>
                </div>
              </div>
              <div class="right">
                ${l.best_score ? `<span class="pill ${l.best_score === 100 ? 'gold' : 'green'}">最高 ${l.best_score} 分</span>` : ''}
                <span class="btn btn-sm ${l.status === 'completed' ? '' : 'btn-primary'}">
                  ${l.status === 'completed' ? '再练一次' : l.attempts ? '继续' : '开始'}</span>
              </div>
            </div>`).join('')}
        </div>
      </div>`);
  }

  /* ---------------------------------------------------------------- 学习播放器 */

  let player = null;

  async function renderLesson(id) {
    state.meta = { title: '沉浸式学习中', sub: '完成全部练习即可结算经验值' };
    setView('<div class="empty"><span class="ico">⏳</span>准备学习内容…</div>');
    const data = await api('/api/lessons/' + id);
    player = {
      ...data,
      idx: 0,
      correct: 0,
      answered: false,
      startedAt: Date.now(),
      log: [],
    };
    if (!player.exercises.length) {
      setView('<div class="empty"><span class="ico">📭</span>这节课还没有练习题</div>');
      return;
    }
    renderPlayer();
  }

  function playerHeader() {
    const p = player;
    const total = p.exercises.length;
    const pct = Math.round((p.idx / total) * 100);
    return `
      <div class="player-head">
        <a class="btn btn-sm btn-ghost" href="#/course/${p.course.id}">‹ 退出</a>
        <div style="flex:1">
          <div style="font-weight:680">${esc(p.lesson.title)}</div>
          <div class="card-sub">${p.language?.flag || ''} ${esc(p.language?.name || '')} · ${p.course.level} · ${esc(p.lesson.moduleLabel)}</div>
        </div>
        <span class="pill brand">${p.idx + 1} / ${total}</span>
        <span class="pill green">✓ ${p.correct}</span>
      </div>
      <div class="player-progress"><i style="width:${pct}%"></i></div>`;
  }

  const TYPE_LABEL = {
    mcq: '选择题', fill: '填空题', listen_choice: '听力选择', listen_type: '听力听写', speak: '口语跟读',
  };

  function renderPlayer() {
    const p = player;
    if (p.idx >= p.exercises.length) return renderLessonSummary();
    const ex = p.exercises[p.idx];
    const lang = p.language?.voice || (p.course.lang === 'ja' ? 'ja-JP' : p.course.lang === 'ko' ? 'ko-KR' : 'en-US');
    const isAudio = ['listen_choice', 'listen_type', 'speak'].includes(ex.type);

    let body = '';
    if (ex.options && ex.options.length) {
      body = `<div class="options" id="options">
        ${ex.options.map((o, i) => `
          <div class="opt" data-opt="${i}">
            <span class="mark">${String.fromCharCode(65 + i)}</span><span>${esc(o)}</span>
          </div>`).join('')}
      </div>`;
    } else if (['fill', 'listen_type'].includes(ex.type)) {
      body = `<div>
        <input class="input" id="answer-input" placeholder="在此输入答案…" autocomplete="off" />
      </div>`;
    } else if (ex.type === 'speak') {
      body = `
        <div class="audio-bar">
          <button class="play-btn" id="play-audio" title="播放示范发音">🔊</button>
          <div class="waves" id="waves">${Array.from({ length: 28 }, () => '<i></i>').join('')}</div>
        </div>
        <div class="mic-zone">
          <button class="mic-btn" id="mic-btn" title="点击开始跟读">🎤</button>
          <div class="heard" id="heard">${SR ? '点击麦克风，朗读上面的句子' : '当前浏览器不支持语音识别，可先听示范再自行练习'}</div>
          ${SR ? '' : '<button class="btn btn-sm" id="manual-pass">我已跟读完成</button>'}
        </div>`;
    }

    setView(`
      <div class="player-wrap">
        ${playerHeader()}
        <div class="ex-card">
          <div>
            <div class="ex-type">${TYPE_LABEL[ex.type] || ex.type}</div>
            <div class="ex-prompt" style="margin-top:8px">${esc(ex.prompt || '')}</div>
            ${ex.prompt_translation ? `<div class="ex-trans" style="margin-top:8px">${esc(ex.prompt_translation)}</div>` : ''}
          </div>
          ${isAudio && ex.type !== 'speak' ? `
            <div class="audio-bar">
              <button class="play-btn" id="play-audio" title="播放音频">🔊</button>
              <div class="waves" id="waves">${Array.from({ length: 28 }, () => '<i></i>').join('')}</div>
            </div>` : ''}
          ${body}
          ${ex.hint ? `<div class="ex-hint">💡 ${esc(ex.hint)}</div>` : ''}
          <div id="feedback"></div>
          <div class="row" id="ex-footer">
            ${['fill', 'listen_type'].includes(ex.type)
              ? '<button class="btn btn-primary" id="submit-answer" disabled>提交答案</button>' : ''}
            <div class="spacer"></div>
            <button class="btn" id="skip-btn" style="display:none">下一题 ›</button>
          </div>
        </div>
      </div>`);

    bindExercise(ex, lang);
  }

  function bindExercise(ex, lang) {
    const p = player;
    p.answered = false;

    const playBtn = qs('#play-audio');
    const waves = qs('#waves');
    if (playBtn && ex.audio) {
      const doPlay = async () => {
        playBtn.classList.add('playing');
        if (waves) waves.classList.add('active');
        await speak(ex.audio, lang);
        playBtn.classList.remove('playing');
        if (waves) waves.classList.remove('active');
      };
      playBtn.addEventListener('click', doPlay);
      setTimeout(doPlay, 420); // 听力题自动播放一次
    }

    const nextBtn = qs('#skip-btn');

    const finishAnswer = (isCorrect, detailHtml) => {
      if (p.answered) return;
      p.answered = true;
      if (isCorrect) p.correct++;
      p.log.push({ id: ex.id, correct: isCorrect });
      qs('#feedback').innerHTML = `
        <div class="feedback ${isCorrect ? 'ok' : 'no'}">
          <b>${isCorrect ? '✅ 回答正确' : '❌ 回答有误'}</b>
          ${ex.answer && !isCorrect ? `<div>正确答案：<b>${esc(ex.answer)}</b></div>` : ''}
          ${ex.explanation ? `<div style="margin-top:6px;color:var(--text-dim)">${esc(ex.explanation)}</div>` : ''}
          ${detailHtml || ''}
        </div>`;
      qsa('.opt').forEach((n) => n.classList.add('disabled'));
      const inp = qs('#answer-input'); if (inp) inp.disabled = true;
      const sub = qs('#submit-answer'); if (sub) sub.disabled = true;
      const mic = qs('#mic-btn'); if (mic) mic.disabled = true;
      if (nextBtn) {
        nextBtn.style.display = '';
        nextBtn.className = 'btn btn-primary';
        nextBtn.textContent = p.idx + 1 >= p.exercises.length ? '查看结果 ›' : '下一题 ›';
        nextBtn.onclick = () => { p.idx++; renderPlayer(); };
        nextBtn.focus();
      }
    };

    // 选择题
    qsa('.opt').forEach((node) => node.addEventListener('click', () => {
      if (p.answered) return;
      const chosen = ex.options[Number(node.dataset.opt)];
      const isCorrect = checkAnswer(chosen, ex.answer, ex.lang || p.course.lang)
        || chosen === ex.answer;
      qsa('.opt').forEach((n) => {
        const val = ex.options[Number(n.dataset.opt)];
        if (val === ex.answer) n.classList.add('right');
        else if (n === node) n.classList.add('wrong');
      });
      finishAnswer(isCorrect);
    }));

    // 填空题 / 听写
    const inp = qs('#answer-input');
    const subBtn = qs('#submit-answer');
    if (inp && subBtn) {
      inp.addEventListener('input', () => { subBtn.disabled = !inp.value.trim(); });
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && inp.value.trim()) { e.preventDefault(); subBtn.click(); }
      });
      subBtn.addEventListener('click', () => {
        const ok = checkAnswer(inp.value, ex.answer, p.course.lang);
        finishAnswer(ok, `<div style="margin-top:6px;color:var(--text-dim)">你的答案：${esc(inp.value.trim())}</div>`);
      });
      setTimeout(() => inp.focus(), 60);
    }

    // 口语跟读
    const micBtn = qs('#mic-btn');
    if (micBtn && SR) {
      const rec = new SR();
      rec.lang = lang;
      rec.interimResults = false;
      rec.maxAlternatives = 3;
      let recording = false;
      micBtn.addEventListener('click', () => {
        if (recording || player.answered) return;
        recording = true;
        micBtn.classList.add('rec');
        qs('#heard').textContent = '正在聆听…请朗读句子';
        try { rec.start(); } catch { /* already started */ }
      });
      rec.onresult = (ev) => {
        const alts = Array.from(ev.results[0]).map((a) => a.transcript);
        const best = alts.reduce((acc, cur) => {
          const s = similarity(normalizeText(cur, p.course.lang), normalizeText(ex.answer, p.course.lang));
          return s > acc.score ? { text: cur, score: s } : acc;
        }, { text: alts[0], score: 0 });
        const score = Math.round(best.score * 100);
        const ok = best.score >= 0.72;
        qs('#heard').innerHTML = `识别到：<b>${esc(best.text)}</b>`;
        finishAnswer(ok, `<div style="margin-top:6px;color:var(--text-dim)">跟读相似度 <b>${score}%</b>（阈值 72%）</div>`);
      };
      rec.onerror = (e) => {
        recording = false;
        micBtn.classList.remove('rec');
        const msg = e.error === 'not-allowed' ? '麦克风权限被拒绝，请在浏览器中允许后重试'
          : e.error === 'no-speech' ? '没有听到声音，请再试一次' : '语音识别失败：' + e.error;
        qs('#heard').textContent = msg;
      };
      rec.onend = () => { recording = false; micBtn.classList.remove('rec'); };
    }

    const manual = qs('#manual-pass');
    if (manual) manual.addEventListener('click', () => finishAnswer(true, '<div style="margin-top:6px;color:var(--text-dim)">已按自评记录完成</div>'));

    // 允许跳过未答题目（不计分）
    if (nextBtn) {
      nextBtn.style.display = '';
      nextBtn.className = 'btn btn-ghost';
      nextBtn.textContent = '跳过 ›';
      nextBtn.onclick = () => { p.idx++; renderPlayer(); };
    }
  }

  async function renderLessonSummary() {
    const p = player;
    const total = p.exercises.length;
    const score = Math.round((p.correct / total) * 100);
    const minutes = Math.max(0.5, Math.round(((Date.now() - p.startedAt) / 60000) * 10) / 10);
    setView('<div class="empty"><span class="ico">⏳</span>正在结算…</div>');

    let result;
    try {
      result = await api(`/api/lessons/${p.lesson.id}/complete`, 'POST', {
        correct: p.correct, total, minutes,
      });
    } catch (e) {
      setView(`<div class="empty"><span class="ico">⚠️</span>${esc(e.message)}
        <div style="margin-top:16px"><a class="btn" href="#/course/${p.course.id}">返回课程</a></div></div>`);
      return;
    }

    state.user.stats = { ...state.user.stats, ...result.stats };
    (result.unlocked || []).forEach((a) => toast(`成就解锁：${a.icon} ${a.title}`, 'badge'));

    setView(`
      <div class="player-wrap">
        <div class="card pad-lg" style="text-align:center">
          <div class="score-hero">
            <div class="big">${result.score}</div>
            <div class="card-sub" style="margin-top:6px">答对 ${result.correct} / ${result.total} 题 · 用时 ${minutes} 分钟</div>
          </div>
          <div style="margin:18px 0">
            <span class="xp-pop">⭐ +${result.xpGained} XP</span>
          </div>
          <p style="color:var(--text-dim)">${esc(result.message)}</p>
          <div class="grid cols-3" style="margin:22px 0">
            <div class="metric"><span class="k">当前等级</span><span class="v">Lv.${result.stats.level}<small>${esc(result.stats.levelTitle)}</small></span></div>
            <div class="metric"><span class="k">连续打卡</span><span class="v">${result.stats.streak}<small>天</small></span></div>
            <div class="metric"><span class="k">累计经验</span><span class="v">${result.stats.xp}<small>XP</small></span></div>
          </div>
          <div class="progress" style="margin-bottom:22px"><i style="width:${Math.round((result.stats.levelProgress || 0) * 100)}%"></i></div>
          <div class="row" style="justify-content:center">
            <button class="btn" id="retry">再练一次</button>
            <a class="btn" href="#/course/${p.course.id}">返回课程</a>
            <a class="btn btn-primary" href="#/home">回到首页</a>
          </div>
          ${result.unlocked && result.unlocked.length ? `
            <div class="divider"></div>
            <div class="card-sub">本次解锁成就</div>
            <div class="row" style="justify-content:center;margin-top:10px">
              ${result.unlocked.map((a) => `<span class="pill gold">${a.icon} ${esc(a.title)}</span>`).join('')}
            </div>` : ''}
        </div>
      </div>`);

    const retry = qs('#retry');
    if (retry) retry.addEventListener('click', () => renderLesson(p.lesson.id));
  }

  /* ---------------------------------------------------------------- 单词复习（SRS） */

  let reviewState = null;

  async function renderReview() {
    state.meta = NAV[2];
    setView('<div class="empty"><span class="ico">⏳</span>正在准备复习队列…</div>');
    const data = await api('/api/review/queue?limit=20');
    state.reviewCount = data.counts.due;
    reviewState = { ...data, i: 0, flipped: false, done: 0, xp: 0, revealed: new Set() };

    if (!data.cards.length) {
      setView(`
        <div class="flash-wrap">
          <div class="card pad-lg" style="text-align:center">
            <div style="font-size:3rem">🎉</div>
            <div class="card-title" style="justify-content:center;margin-top:12px">今日复习已清空</div>
            <p class="card-sub">记忆库中共有 ${data.counts.total} 个单词，已掌握 ${data.counts.mastered} 个。</p>
            <div class="grid cols-3" style="margin:22px 0">
              <div class="metric"><span class="k">等待复习</span><span class="v">${data.counts.due}</span></div>
              <div class="metric"><span class="k">学习中的词</span><span class="v">${data.counts.learning}</span></div>
              <div class="metric"><span class="k">已掌握</span><span class="v">${data.counts.mastered}</span></div>
            </div>
            <a class="btn btn-primary" href="#/courses">去学新课程</a>
          </div>
        </div>`);
      return;
    }
    renderReviewCard();
  }

  function renderReviewCard() {
    const r = reviewState;
    if (r.i >= r.cards.length) return renderReviewDone();
    const card = r.cards[r.i];
    const lang = card.lang === 'ja' ? 'ja-JP' : card.lang === 'ko' ? 'ko-KR' : 'en-US';

    setView(`
      <div class="flash-wrap stack">
        <div class="row">
          <a class="btn btn-sm btn-ghost" href="#/home">‹ 返回</a>
          <div class="spacer"></div>
          <span class="pill">${r.i + 1} / ${r.cards.length}</span>
          <span class="pill brand" id="rv-xp">⭐ ${r.xp} XP</span>
        </div>
        <div class="progress thin"><i style="width:${Math.round((r.i / r.cards.length) * 100)}%"></i></div>

        <div class="flashcard ${r.flipped ? 'flipped' : ''}" id="flashcard">
          <div class="flash-inner">
            <div class="flash-face">
              <span class="pill">${(LANG_META[card.lang] || {}).flag || ''} ${esc(LANG_LABEL[card.lang] || card.lang)} · ${esc(card.level || '')}</span>
              <div class="flash-word">${esc(card.word)}</div>
              ${card.reading && card.reading !== card.word ? `<div class="flash-reading">${esc(card.reading)}</div>` : ''}
              <button class="btn btn-sm" id="rv-play">🔊 听发音</button>
              <div class="card-sub">点击卡片查看释义</div>
            </div>
            <div class="flash-face back">
              <div class="flash-meaning">${esc(card.meaning)}</div>
              ${card.pos ? `<span class="pill">${esc(card.pos)}</span>` : ''}
              ${card.example ? `<div class="flash-ex">${esc(card.example)}<br/><span style="color:var(--text-faint)">${esc(card.example_translation || '')}</span></div>` : ''}
            </div>
          </div>
        </div>

        <div id="rate-zone">
          ${r.flipped ? `
            <div class="rate-grid">
              <button class="btn rate-btn" data-q="0"><b>完全忘记</b><span>重来</span></button>
              <button class="btn rate-btn" data-q="3"><b>有点困难</b><span>1 天后</span></button>
              <button class="btn rate-btn" data-q="4"><b>记得住</b><span>约 6 天后</span></button>
              <button class="btn btn-primary rate-btn" data-q="5"><b>非常轻松</b><span>更久之后</span></button>
            </div>` : `
            <button class="btn btn-primary btn-block btn-lg" id="rv-flip">显示释义</button>`}
        </div>
      </div>`);

    const playBtn = qs('#rv-play');
    const doPlay = (e) => { e.stopPropagation(); speak(card.word, lang); };
    if (playBtn) playBtn.addEventListener('click', doPlay);

    qs('#flashcard').addEventListener('click', () => {
      if (r.flipped) return;
      r.flipped = true;
      renderReviewCard();
    });

    const flip = qs('#rv-flip');
    if (flip) flip.addEventListener('click', () => { r.flipped = true; renderReviewCard(); });

    qsa('[data-q]').forEach((b) => b.addEventListener('click', () => submitReview(Number(b.dataset.q))));
  }

  async function submitReview(quality) {
    const r = reviewState;
    const card = r.cards[r.i];
    try {
      const out = await api('/api/review/submit', 'POST', { word_id: card.word_id, quality });
      r.xp += out.xpGained;
      state.user.stats = { ...state.user.stats, ...out.stats };
      (out.unlocked || []).forEach((a) => toast(`成就解锁：${a.icon} ${a.title}`, 'badge'));
      r.i++;
      r.flipped = false;
      renderReviewCard();
    } catch (e) { toast(e.message, 'no'); }
  }

  function renderReviewDone() {
    const r = reviewState;
    setView(`
      <div class="flash-wrap">
        <div class="card pad-lg" style="text-align:center">
          <div style="font-size:3rem">🌟</div>
          <div class="card-title" style="justify-content:center;margin-top:10px">本轮复习完成</div>
          <p class="card-sub">共复习 ${r.cards.length} 个单词，获得 ${r.xp} 经验值</p>
          <div class="row" style="justify-content:center;margin-top:22px">
            <a class="btn" href="#/home">回到首页</a>
            <button class="btn btn-primary" id="rv-again">再来一轮</button>
          </div>
        </div>
      </div>`);
    qs('#rv-again').addEventListener('click', () => renderReview());
  }

  /* ---------------------------------------------------------------- 社区 */

  let communityFilter = 'all';
  let communityPosts = [];

  async function renderCommunity() {
    state.meta = NAV[3];
    setView('<div class="empty"><span class="ico">⏳</span>加载社区内容…</div>');
    const [posts, board] = await Promise.all([
      api('/api/community/posts' + (communityFilter === 'all' ? '' : '?lang=' + communityFilter)),
      api('/api/community/leaderboard'),
    ]);
    communityPosts = posts.posts;

    const tabs = [`<button class="tab ${communityFilter === 'all' ? 'on' : ''}" data-lang="all">全部</button>`]
      .concat(['en', 'ja', 'ko'].map((c) =>
        `<button class="tab ${communityFilter === c ? 'on' : ''}" data-lang="${c}">${LANG_META[c].flag} ${LANG_META[c].name}</button>`)).join('');

    setView(`
      <div class="grid" style="grid-template-columns:minmax(0,1fr) 320px;align-items:start;gap:20px">
        <div class="stack">
          <div class="row">
            <div class="tabs" id="cm-tabs">${tabs}</div>
            <div class="spacer"></div>
            <button class="btn btn-primary btn-sm" id="new-post">✍️ 发布动态</button>
          </div>
          <div class="stack" id="post-list">
            ${communityPosts.length ? communityPosts.map((p) => `
              <div class="card hover post-card" data-nav="#/post/${p.id}">
                <div class="row">
                  ${avatar({ nickname: p.author, avatar_color: p.avatar_color }, 34)}
                  <div>
                    <div style="font-weight:640;font-size:.9rem">${esc(p.author)}</div>
                    <div class="card-sub" style="font-size:.74rem">${timeAgo(p.created_at)}</div>
                  </div>
                  <div class="spacer"></div>
                  ${p.lang ? `<span class="pill">${(LANG_META[p.lang] || {}).flag || ''} ${esc(LANG_LABEL[p.lang] || '')}</span>` : ''}
                  <span class="pill brand">${esc(p.topic)}</span>
                </div>
                <h3 class="post-title">${esc(p.title)}</h3>
                <div class="post-body">${esc(p.body)}</div>
                <div class="post-meta">
                  <span>❤ ${p.likes} 赞</span><span>💬 ${p.comments} 评论</span>
                </div>
              </div>`).join('')
              : '<div class="empty"><span class="ico">💬</span>还没有动态，点右上角发布第一条吧</div>'}
          </div>
        </div>

        <div class="stack">
          <div class="card">
            <div class="card-title">🏅 学习排行榜</div>
            <p class="card-sub" style="margin-bottom:12px">按累计经验值排名</p>
            <div id="board"></div>
          </div>
          <div class="card">
            <div class="card-title">💡 共学小贴士</div>
            <ul style="margin:10px 0 0;padding-left:18px;color:var(--text-dim);font-size:.85rem;line-height:1.9">
              <li>每天固定时段学习，更容易形成习惯</li>
              <li>发帖分享进度，互相督促更持久</li>
              <li>用「口语跟读」录音对比，进步看得见</li>
            </ul>
          </div>
        </div>
      </div>`);

    const boardBox = qs('#board');
    boardBox.innerHTML = board.leaderboard.map((u) => `
      <div class="rank-row ${u.id === state.user.id ? 'me' : ''}">
        <div class="rank-no ${u.rank <= 3 ? 'top' : ''}">${u.rank}</div>
        ${avatar({ nickname: u.nickname, avatar_color: u.avatar_color }, 30)}
        <div style="flex:1;min-width:0">
          <div style="font-weight:620;font-size:.88rem">${esc(u.nickname)}${u.id === state.user.id ? ' <span style="color:var(--text-faint);font-size:.72rem">(我)</span>' : ''}</div>
          <div class="card-sub" style="font-size:.72rem">${u.lessons} 课 · ${u.badges} 徽章 · 🔥${u.streak}</div>
        </div>
        <div style="font-weight:750;font-size:.9rem">${u.xp}</div>
      </div>`).join('');

    qsa('#cm-tabs .tab').forEach((b) => b.addEventListener('click', () => {
      communityFilter = b.dataset.lang;
      renderCommunity();
    }));

    qs('#new-post').addEventListener('click', openNewPost);
  }

  function openNewPost() {
    openModal(`
      <h3>发布学习动态</h3>
      <p class="card-sub" style="margin-bottom:18px">分享经验、提问求助或者打卡记录，都能获得社区关注。</p>
      <div class="field"><label>标题</label><input class="input" id="np-title" placeholder="例如：坚持 7 天，我的听力正确率提升了 20%" /></div>
      <div class="field"><label>内容</label><textarea class="textarea" id="np-body" placeholder="说说你的学习方法或遇到的问题…"></textarea></div>
      <div class="grid cols-2" style="gap:14px">
        <div class="field"><label>关联语言</label>
          <select class="select" id="np-lang">
            <option value="">不限</option>
            <option value="en">🇬🇧 英语</option><option value="ja">🇯🇵 日语</option><option value="ko">🇰🇷 韩语</option>
          </select></div>
        <div class="field"><label>话题</label>
          <select class="select" id="np-topic">
            <option>经验分享</option><option>答疑求助</option><option>学习打卡</option><option>资源推荐</option><option>语伴招募</option>
          </select></div>
      </div>
      <button class="btn btn-primary btn-block btn-lg" id="np-submit">发布</button>
    `, (card) => {
      qs('#np-submit', card).addEventListener('click', async () => {
        const title = qs('#np-title', card).value.trim();
        const body = qs('#np-body', card).value.trim();
        if (title.length < 2 || body.length < 2) { toast('标题和内容都需要至少 2 个字', 'no'); return; }
        try {
          const out = await api('/api/community/posts', 'POST', {
            title, body, lang: qs('#np-lang', card).value || null, topic: qs('#np-topic', card).value,
          });
          closeModal();
          toast('发布成功！', 'ok');
          communityFilter = 'all';
          renderCommunity();
        } catch (e) { toast(e.message, 'no'); }
      });
    });
  }

  async function renderPost(id) {
    state.meta = { title: '帖子详情', sub: '参与讨论，共学共进' };
    setView('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
    const { post, comments } = await api('/api/community/posts/' + id);

    setView(`
      <div class="stack" style="max-width:820px;margin:0 auto">
        <a class="btn btn-sm btn-ghost" href="#/community" style="align-self:flex-start">‹ 返回社区</a>
        <div class="card pad-lg">
          <div class="row">
            ${avatar({ nickname: post.author, avatar_color: post.avatar_color }, 42)}
            <div>
              <div style="font-weight:660">${esc(post.author)}</div>
              <div class="card-sub" style="font-size:.76rem">${timeAgo(post.created_at)}</div>
            </div>
            <div class="spacer"></div>
            ${post.lang ? `<span class="pill">${(LANG_META[post.lang] || {}).flag || ''} ${esc(LANG_LABEL[post.lang] || '')}</span>` : ''}
            <span class="pill brand">${esc(post.topic)}</span>
          </div>
          <h2 style="margin:18px 0 10px;font-size:1.4rem">${esc(post.title)}</h2>
          <div style="color:var(--text-dim);white-space:pre-wrap;line-height:1.85">${esc(post.body)}</div>
          <div class="divider"></div>
          <div class="post-actions">
            <button class="icon-btn ${post.liked ? 'on' : ''}" id="like-btn">${post.liked ? '❤' : '🤍'} <span>${post.likes}</span></button>
            <span class="icon-btn" style="pointer-events:none">💬 ${post.comments}</span>
          </div>
        </div>

        <div class="card pad-lg">
          <div class="card-title">💬 评论（${post.comments}）</div>
          <div class="field" style="margin-top:14px">
            <textarea class="textarea" id="cm-input" placeholder="写下你的想法…"></textarea>
          </div>
          <button class="btn btn-primary btn-sm" id="cm-submit">发表评论</button>
          <div style="margin-top:10px">
            ${comments.length ? comments.map((c) => `
              <div class="comment">
                ${avatar({ nickname: c.nickname, avatar_color: c.avatar_color }, 34)}
                <div class="body">
                  <div class="who">${esc(c.nickname)}<span class="when">${timeAgo(c.created_at)}</span></div>
                  <div class="text">${esc(c.body)}</div>
                </div>
              </div>`).join('') : '<div class="card-sub" style="padding:14px 0">还没有评论，来抢沙发～</div>'}
          </div>
        </div>
      </div>`);

    qs('#like-btn').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      try {
        const out = await api(`/api/community/posts/${id}/like`, 'POST', {});
        btn.classList.toggle('on', out.liked);
        btn.innerHTML = `${out.liked ? '❤' : '🤍'} <span>${post.likes + (out.liked ? 1 : -1)}</span>`;
        post.liked = out.liked;
        post.likes += out.liked ? 1 : -1;
      } catch (err) { toast(err.message, 'no'); }
    });

    qs('#cm-submit').addEventListener('click', async () => {
      const box = qs('#cm-input');
      const body = box.value.trim();
      if (!body) { toast('评论内容不能为空', 'no'); return; }
      try {
        await api(`/api/community/posts/${id}/comments`, 'POST', { body });
        toast('评论已发布', 'ok');
        renderPost(id);
      } catch (err) { toast(err.message, 'no'); }
    });
  }

  /* ---------------------------------------------------------------- 成就 */

  async function renderAchievements() {
    state.meta = NAV[4];
    setView('<div class="empty"><span class="ico">⏳</span>加载成就…</div>');
    const data = await api('/api/achievements');
    const { summary, achievements, metrics } = data;

    const badges = achievements.map((a) => `
      <div class="badge ${a.unlocked ? 'unlocked' : 'locked'} ${a.tier === 'gold' ? 'tier-gold' : a.tier === 'silver' ? 'tier-silver' : ''}">
        <div class="ico">${a.unlocked ? a.icon : '🔒'}</div>
        <div class="bt">${esc(a.title)}</div>
        <div class="bd">${esc(a.description)}</div>
        <div class="bp">
          <div class="progress thin"><i style="width:${a.unlocked ? 100 : a.progress}%"></i></div>
          <small>${a.unlocked ? `已解锁 · ${timeAgo(a.unlocked_at)}` : `${a.value} / ${a.threshold}`}</small>
        </div>
      </div>`).join('');

    setView(`
      <div class="stack">
        <div class="card pad-lg">
          <div class="row">
            <div>
              <div class="card-title" style="font-size:1.15rem">🏆 成就殿堂</div>
              <p class="card-sub">已点亮 ${summary.unlocked} / ${summary.total} 枚徽章，继续学习解锁更多</p>
            </div>
            <div class="spacer"></div>
            <div class="level-ring" style="--p:${Math.round((summary.unlocked / summary.total) * 100)};width:66px;height:66px">
              <span style="width:52px;height:52px;font-size:.9rem">${summary.unlocked}/${summary.total}</span>
            </div>
          </div>
          <div class="progress" style="margin-top:16px">
            <i style="width:${Math.round((summary.unlocked / summary.total) * 100)}%"></i></div>
        </div>

        <div class="grid cols-4">
          <div class="card"><div class="metric"><span class="k">完成课节</span><span class="v">${metrics.lessons}<small>节</small></span></div></div>
          <div class="card"><div class="metric"><span class="k">掌握单词</span><span class="v">${metrics.words_mastered}<small>个</small></span></div></div>
          <div class="card"><div class="metric"><span class="k">最高连续</span><span class="v">${metrics.streak}<small>天</small></span></div></div>
          <div class="card"><div class="metric"><span class="k">累计经验</span><span class="v">${metrics.xp}<small>XP</small></span></div></div>
        </div>

        <div class="section-head"><h2>徽章墙</h2></div>
        <div class="badge-grid">${badges}</div>
      </div>`);
  }

  /* ---------------------------------------------------------------- 个人中心 */

  async function renderProfile() {
    state.meta = NAV[5];
    setView('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
    const [me, prog] = await Promise.all([api('/api/profile'), api('/api/progress/overview')]);
    state.user = me.user;
    const u = me.user;
    const p = u.profile;
    const s = prog.stats;

    const langTabs = ['en', 'ja', 'ko'].map((c) => {
      const on = (p.target_langs || []).includes(c);
      return `<button class="tab ${on ? 'on' : ''}" data-tl="${c}">${LANG_META[c].flag} ${LANG_META[c].name}</button>`;
    }).join('');

    setView(`
      <div class="stack">
        <div class="card pad-lg">
          <div class="row" style="gap:20px">
            ${avatar(u, 72)}
            <div style="flex:1">
              <h2 style="margin:0;font-size:1.4rem">${esc(u.nickname)}</h2>
              <div class="card-sub">${esc(u.email)} · 加入于 ${new Date(u.created_at).toLocaleDateString('zh-CN')}</div>
              <div class="row" style="margin-top:12px;gap:8px;flex-wrap:wrap">
                <span class="pill brand">Lv.${s.level} ${esc(s.levelTitle)}</span>
                <span class="pill gold">🔥 连续 ${s.streak} 天</span>
                <span class="pill cyan">⭐ ${s.xp} XP</span>
                <span class="pill green">🏅 ${u.achievements.length} 徽章</span>
              </div>
            </div>
            <button class="btn btn-sm" id="logout">退出登录</button>
          </div>
          <div class="divider"></div>
          <div class="row" style="justify-content:space-between;font-size:.8rem;color:var(--text-faint);margin-bottom:6px">
            <span>距 Lv.${s.level + 1} 还需 ${Math.max(0, s.nextLevelXp - s.xp)} XP</span>
            <span>${Math.round((s.levelProgress || 0) * 100)}%</span>
          </div>
          <div class="progress"><i style="width:${Math.round((s.levelProgress || 0) * 100)}%"></i></div>
        </div>

        <div class="grid cols-4">
          <div class="card"><div class="metric"><span class="k">累计学习时长</span><span class="v">${Math.round(s.total_minutes)}<small>分钟</small></span></div></div>
          <div class="card"><div class="metric"><span class="k">完成课节</span><span class="v">${prog.totals.lessonsCompleted}<small>节</small></span></div></div>
          <div class="card"><div class="metric"><span class="k">记忆库单词</span><span class="v">${prog.totals.wordsTotal}<small>个</small></span></div></div>
          <div class="card"><div class="metric"><span class="k">满分课节</span><span class="v">${prog.totals.perfect}<small>次</small></span></div></div>
        </div>

        <div class="grid cols-2">
          <div class="card pad-lg">
            <div class="card-title">⚙️ 学习偏好</div>
            <p class="card-sub" style="margin-bottom:16px">调整后推荐的每日路径会立即生效</p>
            <div class="field"><label>昵称</label><input class="input" id="pf-nick"> </div>
            <div class="field"><label>学习语言</label><div class="tabs" id="pf-langs">${langTabs}</div></div>
            <div class="field"><label>当前水平</label>
              <select class="select" id="pf-level">
                ${['A1', 'A2', 'B1', 'B2'].map((l) => `<option value="${l}" ${p.placement === l ? 'selected' : ''}>${l}</option>`).join('')}
              </select></div>
            <div class="field"><label>每日目标</label>
              <select class="select" id="pf-goal">
                ${[10, 20, 30, 45, 60].map((g) => `<option value="${g}" ${p.daily_goal_min === g ? 'selected' : ''}>${g} 分钟 / 天</option>`).join('')}
              </select></div>
            <button class="btn btn-primary btn-block" id="pf-save">保存偏好</button>
          </div>

          <div class="card pad-lg">
            <div class="card-title">📊 学习概览</div>
            <p class="card-sub" style="margin-bottom:16px">各语言与各能力模块的表现</p>
            ${prog.languages.length ? prog.languages.map((l) => `
              <div style="margin-bottom:14px">
                <div class="row" style="justify-content:space-between;font-size:.86rem;margin-bottom:6px">
                  <span>${l.flag} ${esc(l.name)}</span><span style="color:var(--text-faint)">${l.completed}/${l.total} 课</span>
                </div>
                <div class="progress thin"><i style="width:${l.percent}%"></i></div>
              </div>`).join('') : '<div class="card-sub">暂无学习记录</div>'}
            <div class="divider"></div>
            ${prog.modules.map((m) => `
              <div class="row" style="justify-content:space-between;font-size:.84rem;padding:7px 0">
                <span>${MODULE_ICON[m.module]} ${esc(m.label)}</span>
                <span style="color:var(--text-faint)">${m.accuracy === null ? '暂无数据' : m.accuracy + '%'} · ${m.minutes} 分钟</span>
              </div>`).join('')}
          </div>
        </div>
      </div>`);

    qs('#pf-nick', app).value = u.nickname;
    const chosen = new Set(p.target_langs);
    qsa('#pf-langs .tab').forEach((b) => b.addEventListener('click', () => {
      const c = b.dataset.tl;
      if (chosen.has(c)) { if (chosen.size > 1) chosen.delete(c); } else chosen.add(c);
      b.classList.toggle('on', chosen.has(c));
    }));

    qs('#pf-save').addEventListener('click', async () => {
      try {
        const out = await api('/api/profile', 'PUT', {
          nickname: qs('#pf-nick', app).value.trim(),
          target_langs: [...chosen],
          placement: qs('#pf-level', app).value,
          daily_goal_min: Number(qs('#pf-goal', app).value),
        });
        state.user = out.user;
        toast('偏好已保存', 'ok');
        renderProfile();
      } catch (e) { toast(e.message, 'no'); }
    });

    qs('#logout').addEventListener('click', async () => {
      try { await api('/api/auth/logout', 'POST', {}); } catch { /* ignore */ }
      setToken('');
      state.user = null;
      location.hash = '';
      render();
    });
  }

  /* ================================================================ *
   * 「言灵魔法」模块（英语专属，独立子系统，不影响任何现有页面）
   * ================================================================ */

  const LINGUA_NOTICE_KEY = 'lingua_magic_notice_v1';
  const LG_LANG = 'en-US';

  function awaitingLessonShell(title, sub) {
    state.meta = { title, sub };
    shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
  }

  /** 首次进入言灵模式时的使用须知（每个用户只弹一次） */
  function maybeShowLinguaNotice() {
    if (localStorage.getItem(LINGUA_NOTICE_KEY)) return;
    openModal(`
      <div class="lg-notice">
        <div class="lg-notice-rune">🧙‍♀️✨</div>
        <h3>🪄 小魔女的咒语课堂</h3>
        <p>欢迎来到咒语魔法学园！英语短语就是你的魔法咒语，念对了就能让魔法生效 ✨</p>
        <p class="card-sub" style="margin-top:10px">🌟 判定超级温柔：拼写接近就好，发音自然就行 —— 慢慢来，我们等你～</p>
        <button class="btn btn-primary btn-block btn-lg" id="lg-notice-ok" style="margin-top:18px">📖 翻开咒语书</button>
      </div>`, (card) => {
      qs('#lg-notice-ok', card).addEventListener('click', () => {
        localStorage.setItem(LINGUA_NOTICE_KEY, '1');
        closeModal();
      });
    });
  }

  /** 首页仪表盘入口卡片：以 DOM 注入方式挂载，renderHome 本体零改动 */
  function injectLinguaEntry() {
    const host = qs('#view .stack');
    if (!host || qs('#lingua-entry', host)) return;
    const node = document.createElement('div');
    node.className = 'card pad-lg hover lingua-entry';
    node.id = 'lingua-entry';
    node.setAttribute('data-nav', '#/lingua');
    node.innerHTML = `
      <div class="lg-entry-glow"></div>
      <div class="row" style="gap:18px;position:relative">
        <div class="lg-emblem">🧙‍♀️</div>
        <div style="flex:1;min-width:0">
          <div class="card-title" style="font-size:1.12rem">🪄 咒语魔法学园
            <span class="pill pink">英语专属</span></div>
          <p class="card-sub">小魔女的英语咒语课堂 —— 六步学会一句魔法短语，然后去云朵上跟小妖怪们决斗吧～</p>
        </div>
        <span class="btn btn-primary">翻开咒语书 ›</span>
      </div>`;
    host.insertBefore(node, host.firstChild);
  }

  /* ---------------- 录音（MediaRecorder，无外部依赖） ---------------- */

  const mic = { stream: null, recorder: null, chunks: [], url: null };
  const micSupported = () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);

  async function micStart() {
    if (!micSupported()) throw new Error('当前浏览器不支持录音');
    mic.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mic.chunks = [];
    const mr = new MediaRecorder(mic.stream);
    mic.recorder = mr;
    mr.ondataavailable = (e) => { if (e.data && e.data.size) mic.chunks.push(e.data); };
    mr.start();
  }

  function micStop() {
    return new Promise((resolve) => {
      if (!mic.recorder) return resolve(null);
      const mr = mic.recorder;
      mr.onstop = () => {
        const blob = new Blob(mic.chunks, { type: mr.mimeType || 'audio/webm' });
        if (mic.url) URL.revokeObjectURL(mic.url);
        mic.url = URL.createObjectURL(blob);
        if (mic.stream) mic.stream.getTracks().forEach((t) => t.stop());
        mic.stream = null;
        mic.recorder = null;
        resolve(mic.url);
      };
      mr.stop();
    });
  }

  function micReset() {
    if (mic.url) { URL.revokeObjectURL(mic.url); mic.url = null; }
    if (mic.stream) { mic.stream.getTracks().forEach((t) => t.stop()); mic.stream = null; }
    mic.recorder = null;
  }

  /* ---------------- 填空格组件（学习页第 3 步 / 战斗拼写共用） ---------------- */

  function linguaTokens(phrase, blankIdx) {
    const set = new Set(blankIdx);
    let gi = 0;
    return phrase.toLowerCase().split(/\s+/).map((w) => ({
      word: w.split('').map((ch) => {
        const idx = gi++;
        return { ch, idx, blank: set.has(idx) };
      }),
    }));
  }

  function linguaMakeFill(phrase, blankIdx) {
    const letters = phrase.toLowerCase().replace(/[^a-z]/g, '');
    const bank = blankIdx.map((i) => letters[i]);
    for (let i = bank.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [bank[i], bank[j]] = [bank[j], bank[i]];
    }
    return {
      phrase,
      blankIdx: [...blankIdx],
      tokens: linguaTokens(phrase, blankIdx),
      bank: bank.map((letter) => ({ letter, used: false })),
      fill: {},
    };
  }

  const linguaFillDone = (f) => f.blankIdx.every((i) => f.fill[i] !== undefined);

  function linguaFillAnswer(f) {
    const letters = f.phrase.toLowerCase().replace(/[^a-z]/g, '');
    let out = '';
    let gi = 0;
    for (const ch of f.phrase.toLowerCase()) {
      if (!/[a-z]/.test(ch)) { out += ch; continue; }
      const b = f.fill[gi];
      out += b === undefined ? letters[gi] : f.bank[b].letter;
      gi += 1;
    }
    return out;
  }

  function linguaPaintFill(host, f, onChange) {
    const words = f.tokens.map((w) => `<div class="fword">${w.word.map((cell) => {
      if (!cell.blank) return `<span class="fcell fixed">${esc(cell.ch)}</span>`;
      const b = f.fill[cell.idx];
      return `<button type="button" class="fcell slot${b === undefined ? '' : ' on'}" data-slot="${cell.idx}">${
        b === undefined ? '' : esc(f.bank[b].letter)}</button>`;
    }).join('')}</div>`).join('<span class="fspace"></span>');

    const bank = f.bank.map((t, i) =>
      `<button type="button" class="ltile${t.used ? ' used' : ''}" data-bank="${i}"${
        t.used ? ' disabled' : ''}>${esc(t.letter)}</button>`).join('');

    host.innerHTML = `
      <div class="fill-words">${words}</div>
      <div class="fill-note">点击下方字母填入空格（自动跳下一格），点击已填的空格可取回字母</div>
      <div class="bank">${bank}</div>`;

    qsa('[data-bank]', host).forEach((btn) => btn.addEventListener('click', () => {
      const i = Number(btn.dataset.bank);
      if (f.bank[i].used) return;
      const empty = f.blankIdx.find((idx) => f.fill[idx] === undefined);
      if (empty === undefined) return;
      f.bank[i].used = true;
      f.fill[empty] = i;
      linguaPaintFill(host, f, onChange);
      if (onChange) onChange();
    }));

    qsa('[data-slot]', host).forEach((btn) => btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.slot);
      const b = f.fill[idx];
      if (b === undefined) return;
      f.bank[b].used = false;
      delete f.fill[idx];
      linguaPaintFill(host, f, onChange);
      if (onChange) onChange();
    }));
  }

  /** 录音面板：录音 → 回放 → 自评（无麦克风时降级为纯自评，不阻塞流程） */
  function linguaRecordPanelHtml(rec) {
    if (!micSupported()) {
      return `
        <div class="lg-downgrade">当前环境无法调用麦克风，已切换为「跟读自评」模式 —— 请先听标准音，
          自己大声跟读一遍，再如实选择。</div>
        <div class="row wrap" style="gap:10px;margin-top:14px">
          <button class="btn" id="lg-retry-rec">再试一次</button>
          <button class="btn btn-primary" id="lg-pass-rec">及格，继续</button>
        </div>`;
    }
    if (rec.state === 'recording') {
      return `<div class="mic-zone">
          <button class="mic-btn rec" id="lg-rec-toggle">⏹</button>
          <div class="heard">正在聆听你的言灵…再次点击结束录音</div>
        </div>`;
    }
    if (rec.state === 'recorded') {
      return `
        <div class="lg-playback">
          <audio controls src="${rec.url}"></audio>
        </div>
        <div class="row wrap" style="gap:10px;margin-top:14px">
          <button class="btn" id="lg-retry-rec">再试一次</button>
          <button class="btn btn-primary" id="lg-pass-rec">及格，继续</button>
        </div>`;
    }
    return `<div class="mic-zone">
        <button class="mic-btn" id="lg-rec-toggle">🎤</button>
        <div class="heard">点击麦克风，跟读上面的咒语</div>
      </div>`;
  }

  function linguaBindRecordPanel(host, rec, opts) {
    const toggle = qs('#lg-rec-toggle', host);
    if (toggle) toggle.addEventListener('click', async () => {
      if (mic.recorder) {
        await micStop();
        rec.state = 'recorded';
        rec.url = mic.url;
        paint();
        return;
      }
      try {
        await micStart();
        rec.state = 'recording';
        paint();
      } catch (e) {
        toast(e.message || '无法开始录音，请检查麦克风权限', 'no');
      }
    });

    const retry = qs('#lg-retry-rec', host);
    if (retry) retry.addEventListener('click', async () => {
      micReset();
      rec.state = 'idle';
      rec.retried = true;
      opts.onRetry && opts.onRetry();
      paint();
      await speak(opts.phrase, LG_LANG);   // 再放一遍标准音
    });

    const pass = qs('#lg-pass-rec', host);
    if (pass) pass.addEventListener('click', () => {
      micReset();
      opts.onPass && opts.onPass(rec.retried);
    });

    function paint() { linguaPaintRecord(host, rec, opts); }
  }

  function linguaPaintRecord(host, rec, opts) {
    host.innerHTML = linguaRecordPanelHtml(rec);
    linguaBindRecordPanel(host, rec, opts);
  }

  /* ---------------- 言灵首页 #/lingua ---------------- */

  async function renderLinguaHome() {
    const [today, prof] = await Promise.all([api('/api/lingua/today'), api('/api/lingua/profile')]);
    const newList = today.newPhrases || [];
    const dueList = today.reviewPhrases || [];
    const first = newList[0] ? newList[0].id : (dueList[0] ? dueList[0].id : null);

    const taskRow = (icon, title, sub, count, list) => `
      <div class="lg-task">
        <div class="lg-task-ico">${icon}</div>
        <div style="flex:1;min-width:0">
          <div class="pt">${esc(title)} <span class="pill brand">${count} 条</span></div>
          <div class="pr">${esc(sub)}</div>
          ${list.length ? `<div class="lg-chips">${list.map((p) =>
            `<button class="lg-chip" data-nav="#/lingua/learn/${p.id}">${esc(p.phrase)}<i>${
              p.mastery ? p.mastery + '%' : '新'}</i></button>`).join('')}</div>` : ''}
        </div>
      </div>`;

    const dist = {};
    (prof.distribution || []).forEach((d) => { dist[d.tier] = d; });
    const distHtml = [
      { key: 'super', label: '🧚 妖精级', cls: 'super' },
      { key: 'normal', label: '🌟 完美',   cls: 'normal' },
      { key: 'weak',  label: '💫 稍弱',   cls: 'weak' },
      { key: 'miss',  label: '🍬 走神啦', cls: 'miss' },
    ].map((t) => `
      <div class="lg-dist-row">
        <span class="lg-dist-name tier-${t.cls}">${t.label}</span>
        <span style="color:var(--text-faint);font-size:.8rem">${dist[t.key] ? dist[t.key].count : 0} 次 · ${dist[t.key] ? dist[t.key].damage : 0} 魔法</span>
      </div>`).join('');

    setView(`
      <div class="stack lg-wrap">
        <div class="lg-banner">
          <div class="lg-banner-glow"></div>
          <div class="row" style="position:relative;gap:20px">
            <div class="lg-emblem big">🧙‍♀️</div>
            <div style="flex:1">
              <h2 class="lg-title">咒语魔法学园</h2>
              <p class="lg-sub">🌈 念对咒语，云朵会下雨、糖果会发芽；念错了，小妖怪就要来捣乱啦～</p>
              <div class="row wrap" style="gap:10px;margin-top:12px">
                <span class="pill gold">🔥 连续修炼 ${today.streak} 天</span>
                <span class="pill brand">平均熟练度 ${prof.overview.avgMastery}%</span>
                <span class="pill cyan">✨ 已掌握 ${prof.overview.mastered} / ${prof.overview.totalPhrases}</span>
                <span class="pill pink">🍬 击退 ${prof.battles} 个小妖怪</span>
              </div>
            </div>
          </div>
          <div class="row wrap" style="position:relative;gap:12px;margin-top:20px">
            <button class="btn btn-primary btn-lg" id="lg-start-learn" ${first ? '' : 'disabled'}>
              ${first ? '📖 翻开咒语书' : '🌟 今天的咒语已经学完啦'}</button>
            <button class="btn btn-lg" id="lg-start-battle">🗡️ 去找小妖怪决斗</button>
          </div>
        </div>

        <div class="grid cols-2" style="align-items:start">
          <div class="card pad-lg">
            <div class="section-head"><h2>今日任务</h2></div>
            <div class="stack" style="gap:12px">
              ${taskRow('🌱', '学习新咒语', '从零开始掌握 3 条常用短语', newList.length, newList)}
              ${taskRow('🔁', '复习到期咒语', '按遗忘曲线巩固已学短语', dueList.length, dueList)}
            </div>
          </div>

          <div class="stack">
            <div class="card pad-lg">
              <div class="card-title">📖 熟练度概览</div>
              <div class="grid cols-2" style="gap:14px;margin-top:14px">
                <div class="metric"><span class="k">平均熟练度</span><span class="v">${prof.overview.avgMastery}<small>%</small></span></div>
                <div class="metric"><span class="k">已学咒语</span><span class="v">${prof.overview.studied}<small>条</small></span></div>
                <div class="metric"><span class="k">已掌握</span><span class="v">${prof.overview.mastered}<small>条</small></span></div>
                <div class="metric"><span class="k">连续天数</span><span class="v">${prof.streak}<small>天</small></span></div>
              </div>
              <div class="divider"></div>
              <div class="card-sub">战斗档位分布</div>
              <div style="margin-top:10px">${distHtml}</div>
            </div>
          </div>
        </div>

        <div class="card pad-lg">
          <div class="section-head"><h2>我已掌握得最好的咒语</h2>
            <div class="spacer"></div><span class="card-sub">按熟练度排序</span></div>
          ${(prof.topPhrases || []).length
            ? `<div class="stack" style="gap:10px">${prof.topPhrases.map((p) => `
              <div class="row" style="gap:14px">
                <div style="min-width:130px;font-weight:640">${esc(p.phrase)}</div>
                <div style="flex:1">
                  <div class="progress thin"><i style="width:${p.mastery}%"></i></div>
                </div>
                <div style="width:190px;text-align:right;font-size:.78rem;color:var(--text-faint)">
                  ${p.mastery}%${p.battleBestTier ? ` · 战斗最佳：${esc(p.battleBestTier)}` : ''}</div>
              </div>`).join('')}</div>`
            : '<div class="empty"><span class="ico">🌱</span>还没有学过咒语，先完成今日学习任务吧</div>'}
        </div>
      </div>`);

    const learnBtn = qs('#lg-start-learn');
    if (learnBtn && first) learnBtn.addEventListener('click', () => navigate('#/lingua/learn/' + first));
    qs('#lg-start-battle').addEventListener('click', () => navigate('#/lingua/battle'));
  }

  /* ---------------- 学习页 #/lingua/learn/:id（六步） ---------------- */

  let lingLearn = null;

  const LEARN_STEPS = ['听音', '释义', '试拼', '跟读', '正式拼写', '内容展开'];

  async function renderLinguaLearn(phraseId) {
    setView('<div class="empty"><span class="ico">⏳</span>正在凝聚咒语…</div>');
    if (!phraseId) {
      setView('<div class="empty"><span class="ico">📭</span>没有指定咒语，请从言灵首页进入</div>');
      return;
    }
    const data = await api('/api/lingua/phrase/' + phraseId);
    lingLearn = {
      data,
      phrase: data.phrase,
      step: 1,
      fill: linguaMakeFill(data.phrase.phrase, data.blanks),
      trial: null,
      result: null,
      rec: { state: 'idle', url: null, retried: false },
      done: false,
    };
    renderLearnStep();
    speak(data.phrase.phrase, LG_LANG);
  }

  function learnHeader() {
    const p = lingLearn;
    const pct = Math.round(((p.step - 1) / 6) * 100);
    return `
      <div class="lg-head">
        <a class="btn btn-sm btn-ghost" href="#/lingua">‹ 退出</a>
        <div style="flex:1">
          <div class="lg-step-name">${LEARN_STEPS[p.step - 1]}</div>
          <div class="card-sub">第 ${p.step} / 6 步 · 熟练度 ${p.data.progress.masteryScore}%</div>
        </div>
        <span class="pill brand">✦ 言灵魔法</span>
      </div>
      <div class="player-progress"><i style="width:${pct}%"></i></div>`;
  }

  function renderLearnStep() {
    const p = lingLearn;
    if (p.done) return renderLearnDone();
    const ph = p.phrase;

    let body = '';

    if (p.step === 1) {
      body = `
        <div class="lg-center">
          <div class="lg-rune">🔊</div>
          <p class="lg-lead">先只听声音，不要看文字。仔细记住这条咒语的节奏。</p>
          <button class="play-btn" id="lg-play" title="重播">🔊</button>
        </div>`;

    } else if (p.step === 2) {
      body = `
        <div class="lg-center">
          <div class="lg-label">它的意思</div>
          <div class="lg-meaning">${esc(ph.simple_def)}</div>
          <div class="card-sub" style="margin-top:8px">${esc(ph.grammar_tag || '')}</div>
          <button class="play-btn" id="lg-play" title="再听一次">🔊</button>
        </div>`;

    } else if (p.step === 3) {
      body = `
        <div class="lg-label">把缺失的字母填回去（不计分，随便试）</div>
        <div id="lg-fill"></div>
        <div id="lg-trial"></div>
        <div class="row wrap" style="gap:10px">
          <button class="btn btn-primary" id="lg-try" disabled>试试看</button>
          <button class="btn" id="lg-play">🔊 再听一次</button>
        </div>`;

    } else if (p.step === 4) {
      body = `
        <div class="lg-center">
          <div class="lg-label">正确咒语</div>
          <div class="lg-spell">${esc(ph.phrase)}</div>
          <p class="card-sub">先听标准音，再跟读一遍并录下来回放对比。</p>
          <button class="play-btn" id="lg-play" title="播放标准音">🔊</button>
        </div>
        <div id="lg-rec"></div>`;

    } else if (p.step === 5) {
      body = `
        <div class="lg-label">不看提示，完整拼出这条咒语</div>
        <input class="input lg-input" id="lg-input" placeholder="在此输入咒语…" autocomplete="off" spellcheck="false" />
        <div id="lg-result"></div>
        <button class="btn btn-primary" id="lg-submit" disabled>提交咒语</button>`;

    } else {
      body = `
        <div class="lg-label">例句</div>
        <ul class="lg-list">${(ph.examples || []).map((e) => `<li>${esc(e)}</li>`).join('')}</ul>
        <div class="lg-label" style="margin-top:16px">易错点</div>
        <ul class="lg-list warn">${(ph.pitfalls || []).map((e) => `<li>${esc(e)}</li>`).join('')}</ul>
        <div class="row wrap" style="gap:10px;margin-top:8px">
          <span class="pill">${esc(ph.grammar_tag || '短语')}</span>
          <span class="pill brand">熟练度 ${p.result ? p.result.masteryScore : p.data.progress.masteryScore}%</span>
          ${p.result ? `<span class="pill cyan">将于 ${p.result.intervalDays} 天后复习</span>` : ''}
        </div>`;
    }

    const nextLabel = p.step === 6 ? '完成本节 ✓' : '下一步 ›';
    setView(`
      <div class="lg-wrap stack">
        ${learnHeader()}
        <div class="lg-card">
          ${body}
          <div class="lg-foot">
            <div class="spacer"></div>
            ${p.step === 4 ? '' : `<button class="btn btn-primary" id="lg-next">${nextLabel}</button>`}
          </div>
        </div>
      </div>`);

    bindLearnStep();
  }

  function bindLearnStep() {
    const p = lingLearn;
    const ph = p.phrase;

    const play = qs('#lg-play');
    if (play) play.addEventListener('click', () => speak(ph.phrase, LG_LANG));

    if (p.step === 3) {
      const host = qs('#lg-fill');
      const tryBtn = qs('#lg-try');
      linguaPaintFill(host, p.fill, () => {
        tryBtn.disabled = !linguaFillDone(p.fill) || !!p.trial;
      });
      tryBtn.addEventListener('click', () => {
        const answer = linguaFillAnswer(p.fill);
        const ok = normalizeText(answer, 'en') === normalizeText(ph.phrase, 'en');
        p.trial = { answer, ok };
        qs('#lg-trial').innerHTML = `
          <div class="feedback ${ok ? 'ok' : 'no'}" style="margin-top:14px">
            <b>${ok ? '✅ 拼对了' : '📝 记录一下'}</b>
            <div>正确拼写：<b>${esc(ph.phrase)}</b>${ok ? '' : `<br/>你拼的是：<span style="color:var(--text-faint)">${esc(answer)}</span>`}</div>
            <div style="margin-top:6px;color:var(--text-dim)">这一步不计分，接下来会进入跟读环节。</div>
          </div>`;
        tryBtn.disabled = true;
      });
    }

    if (p.step === 4) {
      const host = qs('#lg-rec');
      linguaPaintRecord(host, p.rec, {
        phrase: ph.phrase,
        onPass: () => { p.step = 5; renderLearnStep(); },
      });
    }

    if (p.step === 5) {
      const input = qs('#lg-input');
      const submit = qs('#lg-submit');
      input.addEventListener('input', () => { submit.disabled = !input.value.trim(); });
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && input.value.trim()) submit.click(); });
      submit.addEventListener('click', async () => {
        submit.disabled = true;
        try {
          const selfResult = p.rec.retried ? 'retry' : 'pass';
          const out = await api('/api/lingua/learn/submit', 'POST', {
            phraseId: ph.id, input: input.value.trim(), selfResult,
          });
          p.result = out;
          const label = { exact: '✅ 全对！咒语完全生效', minor: '⚠️ 小错（1-2 个字母）', miss: '❌ 大错，需要重新记忆' }[out.result];
          qs('#lg-result').innerHTML = `
            <div class="feedback ${out.result === 'exact' ? 'ok' : 'no'}" style="margin-top:14px">
              <b>${label}</b>
              <div>正确拼写：<b>${esc(out.target)}</b></div>
              ${out.result === 'exact' ? '' : `<div>你拼的是：<span style="color:var(--text-faint)">${esc(input.value.trim())}</span>（编辑距离 ${out.distance}）</div>`}
              <div style="margin-top:6px;color:var(--text-dim)">熟练度更新为 <b>${out.masteryScore}%</b>，
                基础攻击力 <b>${out.baseAtk}</b>，${out.intervalDays} 天后再次复习。</div>
            </div>`;
          input.disabled = true;
        } catch (e) {
          toast(e.message, 'no');
          submit.disabled = false;
        }
      });
      setTimeout(() => input.focus(), 60);
    }

    const nextBtn = qs('#lg-next');
    if (nextBtn) nextBtn.addEventListener('click', () => {
      if (p.step === 6) { p.done = true; renderLearnStep(); return; }
      p.step += 1;
      renderLearnStep();
      if (p.step === 1 || p.step === 2 || p.step === 4) speak(ph.phrase, LG_LANG);
    });
  }

  function renderLearnDone() {
    const ph = lingLearn.phrase;
    const r = lingLearn.result;
    setView(`
      <div class="lg-wrap stack">
        <div class="lg-card lg-center">
          <div class="lg-rune big">🧙‍♀️✨</div>
          <div class="lg-title">咒语写进小魔女的魔法书啦！</div>
          <div class="lg-spell">${esc(ph.phrase)}</div>
          ${r ? `<div class="row wrap" style="gap:10px;justify-content:center">
            <span class="pill brand">熟练度 ${r.masteryScore}%</span>
            <span class="pill cyan">✨ 魔法攻击 ${r.baseAtk}</span>
            <span class="pill gold">🍄 ${r.intervalDays} 天后再练</span></div>` : ''}
          <div class="row wrap" style="gap:10px;justify-content:center;margin-top:20px">
            <button class="btn" id="lg-again">🔁 再念一遍</button>
            <a class="btn" href="#/lingua/battle">🗡️ 去找小妖怪决斗</a>
            <a class="btn btn-primary" href="#/lingua">返回言灵首页</a>
          </div>
        </div>
      </div>`);
    qs('#lg-again').addEventListener('click', () => renderLinguaLearn(ph.id));
  }

  /* ---------------- 战斗页 #/lingua/battle ---------------- */

  let lingBattle = null;

  async function renderLinguaBattle() {
    setView('<div class="empty"><span class="ico">⏳</span>正在推演战局…</div>');
    const start = await api('/api/lingua/battle/start');
    lingBattle = {
      start,
      seq: start.sequence,
      i: 0,
      phase: 'narration',
      narrIdx: 0,
      fill: null,
      rec: { state: 'idle', url: null, retried: false },
      last: null,
      log: [],
      enemyHp: start.enemyHp,
      playerHp: start.playerHp,
    };
    micReset();
    renderBattle();
  }

  function battleHud() {
    const b = lingBattle;
    const eHp = Math.max(0, b.enemyHp);
    const pHp = Math.max(0, b.playerHp);
    return `
      <div class="lg-hud">
        <div class="hud-side">
          <div class="hud-name">🍬 ${esc(b.start.enemyName)}</div>
          <div class="hud-bar enemy"><i style="width:${Math.round((eHp / b.start.enemyMaxHp) * 100)}%"></i></div>
          <div class="hud-num">${eHp} / ${b.start.enemyMaxHp} 🍭</div>
        </div>
        <div class="hud-round">回合<br/><b>${Math.min(b.i + 1, b.start.totalRounds)}</b>/${b.start.totalRounds}</div>
        <div class="hud-side right">
          <div class="hud-name">🧙‍♀️ 你</div>
          <div class="hud-bar self"><i style="width:${Math.round((pHp / b.start.playerMaxHp) * 100)}%"></i></div>
          <div class="hud-num">${pHp} / ${b.start.playerMaxHp} ✨</div>
        </div>
      </div>`;
  }

  const TIER_CLASS = { super: 'tier-super', normal: 'tier-normal', weak: 'tier-weak', miss: 'tier-miss' };

  function renderBattle() {
    const b = lingBattle;

    if (b.phase === 'narration') {
      const lines = b.start.narration.slice(0, b.narrIdx + 1);
      setView(`
        <div class="lg-wrap stack">
          <div class="lg-card lg-center">
            <div class="lg-rune big">🧙‍♀️✨</div>
            <div class="lg-narration">${lines.map((l) => `<p>${esc(l)}</p>`).join('')}</div>
            <div class="row" style="justify-content:center;margin-top:20px">
              <button class="btn btn-primary" id="lg-narr-next">
                ${b.narrIdx + 1 < b.start.narration.length ? '继续听…' : '🧹 拿上扫帚出发！'}</button>
            </div>
            <a class="btn btn-sm btn-ghost" href="#/lingua" style="margin-top:14px">‹ 退出战斗</a>
          </div>
        </div>`);
      qs('#lg-narr-next').addEventListener('click', () => {
        if (b.narrIdx + 1 < b.start.narration.length) { b.narrIdx += 1; renderBattle(); return; }
        b.phase = 'hint';
        renderBattle();
      });
      return;
    }

    if (b.phase === 'settle') return renderBattleSettle();

    const cur = b.seq[b.i];
    let body = '';

    if (b.phase === 'hint') {
      body = `
        <div class="lg-center">
          <div class="lg-label">系统提示 · B 档线索</div>
          <div class="lg-hint">「${esc(cur.hint_script)}」</div>
          <div class="card-sub" style="margin-top:10px">${esc(cur.simple_def)}</div>
          <button class="btn btn-primary btn-lg" id="lg-to-spell" style="margin-top:18px">开始填充咒语</button>
        </div>`;
    } else if (b.phase === 'spell') {
      body = `
        <div class="lg-label">把缺失的字母填回去，补全咒语</div>
        <div id="lg-fill"></div>
        <div class="lg-foot" style="justify-content:flex-end">
          <button class="btn btn-primary" id="lg-confirm" disabled>确认咒语 →</button>
        </div>`;
    } else if (b.phase === 'record') {
      body = `
        <div class="lg-center">
          <div class="lg-spell">${esc(cur.phrase)}</div>
          <p class="card-sub">言灵必须出声才有力量 —— 跟读并录音（此环节无法跳过）</p>
          <button class="play-btn" id="lg-play" title="标准音">🔊</button>
        </div>
        <div id="lg-rec"></div>`;
    } else if (b.phase === 'result') {
      const r = b.last;
      body = `
        <div class="lg-center">
          <div class="lg-tier ${TIER_CLASS[r.tier]}">${esc(r.tierLabel)}</div>
          <div class="lg-narration"><p>${esc(r.narration)}</p></div>
          <div class="lg-verdict">
            <div>正确咒语：<b>${esc(r.target)}</b></div>
            ${r.spelling === 'exact' ? '' : `<div>你拼的是：<span style="color:var(--text-faint)">${esc(r.yourAnswer || '（未填）')}</span></div>`}
          </div>
          <div class="row wrap" style="gap:10px;justify-content:center;margin-top:8px">
            <span class="pill ${r.tier === 'super' ? 'gold' : r.tier === 'normal' ? 'green' : r.tier === 'weak' ? 'cyan' : 'pink'}">敌人 ${r.enemyHp} / ${r.enemyMaxHp}</span>
            <span class="pill">自身 ${r.playerHp} / ${r.playerMaxHp}</span>
            <span class="pill brand">连击 ${r.combo}</span>
          </div>
          <button class="btn btn-primary btn-lg" id="lg-next-round" style="margin-top:18px">
            ${r.finished ? '进入结算 →' : '下一回合 →'}</button>
        </div>`;
    }

    setView(`
      <div class="lg-wrap stack">
        ${battleHud()}
        <div class="lg-card lg-battle">${body}</div>
      </div>`);

    if (b.phase === 'hint') {
      qs('#lg-to-spell').addEventListener('click', () => {
        b.fill = linguaMakeFill(cur.phrase, cur.blanks);
        b.phase = 'spell';
        renderBattle();
      });
    }

    if (b.phase === 'spell') {
      const host = qs('#lg-fill');
      const confirm = qs('#lg-confirm');
      linguaPaintFill(host, b.fill, () => { confirm.disabled = !linguaFillDone(b.fill); });
      confirm.addEventListener('click', () => {
        b.rec = { state: 'idle', url: null, retried: false };
        b.phase = 'record';
        renderBattle();
      });
    }

    if (b.phase === 'record') {
      const play = qs('#lg-play');
      if (play) play.addEventListener('click', () => speak(cur.phrase, LG_LANG));
      const host = qs('#lg-rec');
      linguaPaintRecord(host, b.rec, {
        phrase: cur.phrase,
        onPass: (retried) => submitBattleRound(retried),
      });
      speak(cur.phrase, LG_LANG);
    }

    if (b.phase === 'result') {
      qs('#lg-next-round').addEventListener('click', () => {
        if (b.last.finished) { b.phase = 'settle'; renderBattle(); return; }
        b.i += 1;
        b.rec = { state: 'idle', url: null, retried: false };
        b.phase = 'hint';
        renderBattle();
      });
    }
  }

  async function submitBattleRound(retried) {
    const b = lingBattle;
    const cur = b.seq[b.i];
    const answer = linguaFillAnswer(b.fill);
    try {
      const r = await api('/api/lingua/battle/round', 'POST', {
        battleId: b.start.battleId,
        phraseId: cur.phraseId,
        input: answer,
        selfResult: retried ? 'retry' : 'pass',
      });
      b.last = r;
      b.enemyHp = r.enemyHp;
      b.playerHp = r.playerHp;
      b.log.push(r);
      b.phase = 'result';
      renderBattle();
    } catch (e) {
      toast(e.message, 'no');
    }
  }

  async function renderBattleSettle() {
    const b = lingBattle;
    setView('<div class="empty"><span class="ico">⏳</span>正在结算战果…</div>');
    let out;
    try {
      out = await api('/api/lingua/battle/finish', 'POST', { battleId: b.start.battleId });
    } catch (e) {
      setView(`<div class="empty"><span class="ico">⚠️</span>${esc(e.message)}
        <div style="margin-top:16px"><a class="btn" href="#/lingua">返回言灵首页</a></div></div>`);
      return;
    }
    const s = out.summary;
    const dist = ['super', 'normal', 'weak', 'miss'].map((k) => {
      const labels = { super: '🧚 妖精级', normal: '🌟 完美', weak: '💫 稍弱', miss: '🍬 走神啦' };
      return { k, label: labels[k], n: s.distribution[k] };
    });

    setView(`
      <div class="lg-wrap stack">
        <div class="lg-card lg-center">
          <div class="lg-rune big">${s.victory ? '🏆✨' : '🕯️'}</div>
          <div class="lg-title">${s.victory ? '🎉 击退了 ' + esc(s.enemyName) + '！' : '💤 魔法暂时耗尽了…'}</div>
          <div class="lg-tier-big ${s.titleKey === 'nova' ? 'tier-super' : s.titleKey === 'steady' ? 'tier-normal' : s.titleKey === 'narrow' ? 'tier-weak' : 'tier-miss'}">
            ${esc(s.title)}
          </div>
          <p class="card-sub">${esc(s.titleBlurb)}</p>

          <div class="grid cols-3" style="gap:14px;margin:24px 0;width:100%">
            <div class="metric"><span class="k">总伤害</span><span class="v">${s.totalDamage}</span></div>
            <div class="metric"><span class="k">最高连击</span><span class="v">${s.maxCombo}</span></div>
            <div class="metric"><span class="k">敌方剩余</span><span class="v">${s.enemyHp}<small>/ ${s.enemyMaxHp}</small></span></div>
          </div>

          <div class="lg-label">四档分布</div>
          <div class="lg-dist-grid">
            ${dist.map((d) => `<div class="lg-dist-cell"><b class="tier-${d.k}">${d.label}</b><span>${d.n} 次</span></div>`).join('')}
          </div>

          ${s.mvp ? `<div class="lg-mvp">
            <div class="lg-label">MVP 魔咒</div>
            <div class="lg-mvp-phrase">${esc(s.mvp.phrase)}</div>
            <div class="card-sub">${esc(s.mvp.tierLabel)} · 单回合 ${s.mvp.damage} 点伤害</div>
          </div>` : ''}

          <div class="row wrap" style="gap:10px;justify-content:center;margin-top:22px">
            <button class="btn btn-primary" id="lg-battle-again">再战一场 ⚔️</button>
            <a class="btn" href="#/lingua">返回言灵首页</a>
          </div>
          <div class="card-sub" style="margin-top:14px">
            平均熟练度 ${out.overview.avgMastery}% · 已掌握 ${out.overview.mastered}/${out.overview.totalPhrases} · 连续 ${out.streak} 天
          </div>
        </div>
      </div>`);

    qs('#lg-battle-again').addEventListener('click', () => { lingBattle = null; renderLinguaBattle(); });
  }

  /* ---------------------------------------------------------------- 全局事件委托 */

  document.addEventListener('click', (e) => {
    const nav = e.target.closest('[data-nav]');
    if (nav) {
      e.preventDefault();
      navigate(nav.dataset.nav);
    }
  });

  /* ---------------------------------------------------------------- 渲染入口 */

  async function render() {
    const route = parseRoute();
    state.route = route.name;

    if (!state.user) {
      try {
        const me = await api('/api/auth/me');
        state.user = me.user;
      } catch {
        state.user = null;
      }
    }

    if (!state.user) { renderAuth(); return; }

    if (!state.user.profile.onboarded && route.name !== 'onboarding') {
      navigate('#/onboarding');
      return;
    }
    if (route.name === 'onboarding' && state.user.profile.onboarded) {
      // 允许主动重进引导页
    }

    try {
      switch (route.name) {
        case 'onboarding': renderOnboarding(); break;
        case 'home': {
          state.meta = NAV[0];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderHome();
          injectLinguaEntry();
          break;
        }
        case 'courses': {
          state.meta = NAV[1];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderCourses();
          break;
        }
        case 'course': {
          state.meta = { title: '课程详情', sub: '按顺序完成课节' };
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderCourseDetail(route.param);
          break;
        }
        case 'lesson': {
          state.meta = { title: '沉浸式学习中', sub: '完成全部练习即可结算经验值' };
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderLesson(route.param);
          break;
        }
        case 'review': {
          state.meta = NAV[2];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderReview();
          break;
        }
        case 'community': {
          state.meta = NAV[3];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderCommunity();
          break;
        }
        case 'post': {
          state.meta = { title: '帖子详情', sub: '参与讨论，共学共进' };
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderPost(route.param);
          break;
        }
        case 'achievements': {
          state.meta = NAV[4];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderAchievements();
          break;
        }
        case 'profile': {
          state.meta = NAV[5];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderProfile();
          break;
        }
        case 'lingua': {
          maybeShowLinguaNotice();
          const sub = route.parts[1];
          if (sub === 'learn') {
            awaitingLessonShell('言灵魔法 · 学习', '六步掌握一条咒语');
            await renderLinguaLearn(route.parts[2]);
          } else if (sub === 'battle') {
            awaitingLessonShell('言灵魔法 · 战斗', '说出正确咒语，让魔法生效');
            await renderLinguaBattle();
          } else {
            awaitingLessonShell('言灵魔法', '英语专属 · 沉浸式咒语训练');
            await renderLinguaHome();
          }
          break;
        }
        default: {
          state.meta = NAV[0];
          shell('<div class="empty"><span class="ico">⏳</span>加载中…</div>');
          await renderHome();
          injectLinguaEntry();
        }
      }
    } catch (err) {
      if (!state.user) { renderAuth(); return; }
      state.meta = state.meta.title ? state.meta : { title: '出错了', sub: '' };
      shell(`<div class="empty"><span class="ico">⚠️</span>${esc(err.message)}
        <div style="margin-top:16px"><a class="btn" href="#/home">回到首页</a></div></div>`);
    }
  }

  // 启动
  render();
})();
